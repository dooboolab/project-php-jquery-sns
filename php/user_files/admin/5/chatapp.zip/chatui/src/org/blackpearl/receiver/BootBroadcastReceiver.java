package org.blackpearl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.blackpearl.service.ChatService;


public class BootBroadcastReceiver extends BroadcastReceiver {
    private static final String ACTION_BOOT_START = "android.intent.action.BOOT_COMPLETED";

    public BootBroadcastReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

        if(intent.getAction().equals(ACTION_BOOT_START)){
            context.startService(new Intent(context, ChatService.class));
            Log.i("Boot Completed", "ChatService Started");
        }

        throw new UnsupportedOperationException("Not yet implemented");
    }
}
