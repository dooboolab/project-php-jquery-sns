package org.blackpearl.task;


import android.os.AsyncTask;
import android.util.Log;
import org.blackpearl.network.Network;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by hyochan on 2014. 8. 12..
 */
public class ChatTask extends AsyncTask<String, Integer, String> {
    String s = "";
    GetChatResult getChatResult;

    public void setOnResultListener(GetChatResult getChatResult){
        if(getChatResult != null){
            this.getChatResult = getChatResult;
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... url) {

        Network network = new Network();

        try{
            s = network.downloadUrl(url[0]);
        } catch (Exception e){
            Log.d("Background Task", e.toString());
        }

        return s;
    }

    //get the returned text from the url
    @Override
    protected void onPostExecute(String result){
        Log.i("서버에서 받은 전체 내용 : ", result);

        String final_result = "";
        try {
            JSONArray json = new JSONArray(result);
            int count = json.length();
            Log.i("json", "json : " + json);

            for(int i=0; i< count; i++){
                JSONObject json_obj = json.getJSONObject(i);
                if(i == 0){
                    final_result += (String) json_obj.get("msg");
                } else{
                    final_result += "\n" + (String) json_obj.get("msg");
                }
            }
            if (getChatResult != null){
                getChatResult.onResultSuccess(1, final_result);
            } else{
                getChatResult.onResultFail(0, "받아오질 못했네요...");
            }

        } catch (JSONException e) {
            e.printStackTrace();
            getChatResult.onResultFail(0, "받아오질 못했네요...");
        }
    }

    public interface GetChatResult {
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }
}