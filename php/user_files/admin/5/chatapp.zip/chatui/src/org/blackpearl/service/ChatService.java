package org.blackpearl.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import io.socket.IOAcknowledge;
import io.socket.IOCallback;
import io.socket.SocketIO;
import io.socket.SocketIOException;
import org.blackpearl.activity.ChatActivity;
import org.blackpearl.database.AccessDB;
import org.blackpearl.network.NetworkPreference;
import org.json.JSONException;
import org.json.JSONObject;

public class ChatService extends Service {

    private static final int MY_NOTIFICATION_ID = 1;
    private NotificationManager notificationManager;
    private Notification myNotification;
    private Context context;


    public ChatService() {
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        context = getApplicationContext();
        if(NetworkPreference.getInstance(context).getmSocket() == null) {
            try {
                NetworkPreference.getInstance(context).setmSocket(new SocketIO(NetworkPreference.getInstance(context).getServer_url()));
            } catch (Exception e) {
                Log.d("Exception while getting url", e.toString());
            }
            socketClient(NetworkPreference.getInstance(context).getmSocket());
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    private void socketClient(final SocketIO socket){
        socket.connect(new IOCallback() {
            @Override
            public void onMessage(JSONObject json, IOAcknowledge ack) {
                try {
                    Log.i("Server said", "Server said" + json.toString(2));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onMessage(String data, IOAcknowledge ack) {
                Log.i("Server said", "Server said" + data);
            }

            @Override
            public void onError(SocketIOException socketIOException) {
                Log.i("Server Error", "Error occured");
                if(NetworkPreference.getInstance(context).getmSocket() == null) {
                    try {
                        NetworkPreference.getInstance(context).setmSocket(new SocketIO(NetworkPreference.getInstance(context).getServer_url()));
                    } catch (Exception e) {
                        Log.d("Exception while getting url", e.toString());
                    }
                    socketClient(NetworkPreference.getInstance(context).getmSocket());
                }
                socketIOException.printStackTrace();
            }

            @Override
            public void onDisconnect() {
                Log.i("Server Disconnect", "Connection disconnected");
            }

            @Override
            public void onConnect() {
                try {
                    JSONObject json = new JSONObject();
                    json.putOpt("room", "ass");
                    json.putOpt("id", ChatActivity.myId);
                    socket.emit("users", json);
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
                Log.i("Server connect", "Connection connected");
            }

            JSONObject json = new JSONObject();

            @Override
            public void on(String event, IOAcknowledge ack, Object... data) {
                Log.i("Server triggered event", "Server triggered event '" + event + "'" );
                try{
                    Log.i("data", "data : " + data[0]);
                    json = (JSONObject) data[0];
                    // send broadcast to update UI
                    // Log.i("sendReceiver", "sendReceiver");
                    Intent intent = new Intent();
                    intent.setAction("org.blackpearl.getMessage");
                    Bundle bundle = new Bundle();
                    bundle.putString("room", json.get("room").toString());
                    bundle.putString("id", json.get("id").toString());
                    bundle.putString("message", json.get("message").toString());
                    bundle.putInt("type", json.getInt("type"));
                    bundle.putString("date", json.get("date").toString());
                    intent.putExtras(bundle);
                    sendBroadcast(intent);

                    if(ChatActivity.myId.equals( json.get("id").toString()) == false){
                        AccessDB.getInstance(context).insertChat(0, json.get("room").toString()
                                , json.get("id").toString(), json.get("message").toString()
                                , json.getInt("type"), json.get("date").toString());
                    }else{
                        AccessDB.getInstance(context).insertChat(1, json.get("room").toString()
                                , json.get("id").toString(), json.get("message").toString()
                                , json.getInt("type"), json.get("date").toString());
                    }
                } catch(JSONException ex){

                }
                /*
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //stuff that updates ui
                        output.setText(out_buf);
                    }
                });
                */
            }
        });
        // This line is cached until the connection is established.
        // socket.send("Hello Server!");
    }
}
