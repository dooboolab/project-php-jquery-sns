package org.blackpearl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.blackpearl.network.Network;
import org.blackpearl.service.ChatService;

public class NetworkBroadcastReceiver extends BroadcastReceiver {
    public NetworkBroadcastReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

        if(intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")
                || intent.getAction().equals("android.net.wifi.WIFI_STATE_CHANGED")){
            Network network = new Network();
            if(network.isNetworkAvailable(context)==true) {
                context.startService(new Intent(context, ChatService.class));
            }
        }
    }
}