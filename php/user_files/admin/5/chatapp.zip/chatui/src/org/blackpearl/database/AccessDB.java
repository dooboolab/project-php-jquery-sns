package org.blackpearl.database;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.util.Log;
import org.blackpearl.activity.ChatActivity;
import org.blackpearl.data.ChatPreference;

/**
 * Created by hyochan on 14. 10. 29..
 */
public class AccessDB {

    private static final String TAG = "AccessDB";
    private static AccessDB mInstance;
    private SharedPreferences mPref;
    private DBHelper mDBHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private Context context;

    private AccessDB(Context context){
        mPref = PreferenceManager.getDefaultSharedPreferences(context);
        this.context = context;
    }

    public static AccessDB getInstance(Context context){
        if(mInstance == null) mInstance = new AccessDB(context);
        return mInstance;
    }

    // INSERT CHAT_TABLE
    // null, mine, room, id, message, type, date
    public void insertChat(
            int mine,
            String room,
            String id,
            String message,
            int type,
            String date){
        mDBHelper = new DBHelper(context, DBHelper.DATABASE, null, DBHelper.dbVersion);
        db = mDBHelper.getWritableDatabase();
        cursor = db.rawQuery("SELECT * FROM " + DBHelper.CHAT_TABLE, null);

        String sql = "INSERT INTO " + DBHelper.CHAT_TABLE + " VALUES(null, " +
                mine + "," +
                "'" + room + "'," +
                "'" + id + "'," +
                "'" + message + "'," +
                type + "," +
                "'" + date + "'" +
                ")";
        db.execSQL(sql);

        mDBHelper.close();
    }

    public void selectChat(String room){
        mDBHelper = new DBHelper(context, DBHelper.DATABASE, null, DBHelper.dbVersion);
        db = mDBHelper.getWritableDatabase();
        cursor = db.rawQuery("SELECT * FROM " + DBHelper.CHAT_TABLE, null);
        cursor.moveToFirst();


        Boolean mine = false;
        String id = "";
        String message = "";
        int type = 0;
        String date = "";

        // null, mine, room, id, message, type, date
        for(int i=0; i<cursor.getCount(); i++){
            if(cursor.getInt(1) == 0)
                mine = false;
            else mine = true;

            id = cursor.getString(3);
            message = cursor.getString(4);
            type = cursor.getInt(5);
            date = cursor.getString(6);

            ChatActivity.arrayListChat.add(new ChatPreference(
                            mine, room, id, message, type, date)
            );

            Log.i(TAG, "id : " + id + ", message : " + message);

            cursor.moveToNext();
        }
        mDBHelper.close();
    }


}
