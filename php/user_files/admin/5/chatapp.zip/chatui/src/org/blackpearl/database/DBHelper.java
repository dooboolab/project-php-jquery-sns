package org.blackpearl.database;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by hyochan on 2014. 8. 15..
 */
public class DBHelper extends SQLiteOpenHelper {  //데이터베이스 클래스

    public static final String DATABASE = "chat.db";

    //Use Disturb Mode
    public static final String CHAT_TABLE = "chat_table";

    public static final int dbVersion = 1;

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                    int version) {
        super(context, name, factory, version);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + CHAT_TABLE + "(" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "mine INTEGER, " +
                        "room TEXT, " +
                        "id TEXT, " +
                        "message TEXT, " +
                        "type INTEGER, " +
                        "date TEXT" +
                        ");"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXIST" + CHAT_TABLE +" ;");
        onCreate(db);
    }
}