package org.blackpearl.data;

/**
 * Created by hyochan on 14. 10. 21..
 */
public class ChatPreference {

    // room, id, message, type, date

    Boolean mine;
    String room;
    String id;
    String message;
    int type;
    String time;

    public ChatPreference(Boolean mine, String room, String id, String message, int type, String time) {
        this.mine = mine;
        this.room = room;
        this.id = id;
        this.message = message;
        this.type = type;
        this.time = time;
    }

    public Boolean getMine() {
        return mine;
    }

    public void setMine(Boolean mine) {
        this.mine = mine;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
