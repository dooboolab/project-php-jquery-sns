package org.blackpearl.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.blackpearl.R;
import org.blackpearl.data.ChatPreference;

import java.util.ArrayList;

/**
 * Created by hyochan on 14. 10. 21..
 */
public class ChatAdapter extends ArrayAdapter<ChatPreference> {

    private final String TAG = "ChatAdapter";
    Context context;
    ArrayList<ChatPreference> arrayList;


    public ChatAdapter(Context context, int resource, int textViewResourceId, ArrayList<ChatPreference> arrayList) {
        super(context, resource, textViewResourceId, arrayList);
        this.context = context;
        this.arrayList = arrayList;
    }

    class ViewHolder{
        public LinearLayout myLayout;
        public ImageView myImg;
        public TextView myText;
        public TextView myDate;
        public LinearLayout peerLayout;
        public ImageView peerImg;
        public TextView peerText;
        public TextView peerDate;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null){
            LayoutInflater inflater=LayoutInflater.from(context);
            convertView=inflater.inflate(R.layout.list_chat, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.myLayout = (LinearLayout) convertView.findViewById(R.id.layout_my);
            viewHolder.myImg = (ImageView) convertView.findViewById(R.id.img_my);
            viewHolder.myText = (TextView) convertView.findViewById(R.id.text_my);
            viewHolder.myDate = (TextView) convertView.findViewById(R.id.text_date_my);
            viewHolder.peerLayout = (LinearLayout) convertView.findViewById(R.id.layout_peer);
            viewHolder.peerImg = (ImageView) convertView.findViewById(R.id.img_peer);
            viewHolder.peerText = (TextView) convertView.findViewById(R.id.text_peer);
            viewHolder.peerDate = (TextView) convertView.findViewById(R.id.text_date_peer);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Log.i(TAG, "position : " + position + ", mine : " + arrayList.get(position).getMine());
        if(arrayList.get(position).getMine() == true){
            viewHolder.myLayout.setVisibility(View.VISIBLE);
            viewHolder.peerLayout.setVisibility(View.GONE);
            viewHolder.myText.setText(arrayList.get(position).getMessage());
            viewHolder.myDate.setText(arrayList.get(position).getTime());
        }else{
            viewHolder.myLayout.setVisibility(View.GONE);
            viewHolder.peerLayout.setVisibility(View.VISIBLE);
            viewHolder.peerText.setText(arrayList.get(position).getMessage());
            viewHolder.peerDate.setText(arrayList.get(position).getTime());
        }

        return convertView;


    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

}