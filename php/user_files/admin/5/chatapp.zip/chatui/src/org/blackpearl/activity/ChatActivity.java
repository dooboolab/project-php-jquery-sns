package org.blackpearl.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.blackpearl.R;
import org.blackpearl.adapter.ChatAdapter;
import org.blackpearl.data.ChatPreference;
import org.blackpearl.database.AccessDB;
import org.blackpearl.network.NetworkPreference;
import org.blackpearl.service.ChatService;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ChatActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

    Boolean hideUploadLayout = false;
    Context context;

    LinearLayout uploadLayout;
    ImageView iconPlus;
    EditText editChat;
    ListView chatList;
    public static ArrayList<ChatPreference> arrayListChat;
    ChatAdapter chatAdapter;
    Button btnChat;
    MessageBR messageBR;

    public static String myId = "admin";
    public static String room = "ass";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        iconPlus = (ImageView) findViewById(R.id.icon_plus);
        uploadLayout = (LinearLayout) findViewById(R.id.upload_layout);
        chatList = (ListView) findViewById(R.id.chatLists);
        editChat = (EditText) findViewById(R.id.edit_chat);
        btnChat = (Button) findViewById(R.id.btn_chat);

        uploadLayout.setVisibility(View.GONE);

        // StrictMode.enableDefaults();
        /* start : unix.jang => the way of code to ignore the policy violoation */
        StrictMode.ThreadPolicy old = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(old)
                .permitDiskWrites()
                .build());
        //doCorrectStuffThatWritesToDisk();
        StrictMode.setThreadPolicy(old);
        /* end : unix.jang => ignoring policy violation */

        startService(new Intent(context, ChatService.class));

        editChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadLayout.setVisibility(View.GONE);
                hideUploadLayout = false;
            }
        });

        iconPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hideUploadLayout == false){
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(editChat.getWindowToken(), 0);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            uploadLayout.setVisibility(View.VISIBLE);
                        }
                    }, 100);
                    hideUploadLayout = true;
                } else{
                    uploadLayout.setVisibility(View.GONE);
                    hideUploadLayout = false;
                }
            }
        });

        btnChat.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Date date = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                String time = sdf.format(date);
                try {
                    // room, id, message, type, date
                    JSONObject json = new JSONObject();
                    json.putOpt("room", "ass");
                    json.putOpt("id", myId);
                    json.putOpt("message", editChat.getText().toString());
                    json.putOpt("type", 0);
                    json.putOpt("date", time);
                    NetworkPreference.getInstance(context).getmSocket().emit("message", json);
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
                //socket.send("와우 굿!!");
            }
        });

        arrayListChat = new ArrayList<ChatPreference>();
        AccessDB.getInstance(context).selectChat(room);
        chatAdapter = new ChatAdapter(context, R.layout.list_chat, R.id.text_my, arrayListChat);
        chatList.setAdapter(chatAdapter);
        chatAdapter.notifyDataSetChanged();
        chatList.smoothScrollToPosition(arrayListChat.size()-1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(messageBR == null) {
            messageBR = new MessageBR();
            IntentFilter filter = new IntentFilter("org.blackpearl.getMessage");
            registerReceiver(messageBR, filter);
        }
    }

    @Override
    protected void onPause() {
        if(messageBR != null){
            unregisterReceiver(messageBR);
            messageBR = null;
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        startService(new Intent(context, ChatService.class));
        super.onDestroy();
    }

    private class MessageBR extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            String room = intent.getStringExtra("room");
            String id = intent.getStringExtra("id");
            String message = intent.getStringExtra("message");
            int type = intent.getIntExtra("type", 0);
            String time = intent.getStringExtra("date");

            if (action.equals("org.blackpearl.getMessage")) {
                Log.i("onreceived", "getBroadcastMessage : " + message);
                if(id.equals(myId) == false){
                    arrayListChat.add(new ChatPreference(false, room, id, message, type, time));
                }else{
                    arrayListChat.add(new ChatPreference(true, room, id, message, type, time));
                }

                editChat.setText("");
                chatAdapter.notifyDataSetChanged();
                chatList.smoothScrollToPosition(arrayListChat.size()-1);
            }
        }
    }
}
