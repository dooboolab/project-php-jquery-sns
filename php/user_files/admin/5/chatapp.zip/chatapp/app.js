/**
 * Created by hyochan on 2014. 6. 25..
 */
var os = require('os');
var fs = require('fs');
var ejs = require('ejs');
var http = require('http');
var express = require('express'),
    morgan = require('morgan'),
    cookieParser = require('cookie-parser'),
    session = require('express-session'),
    bodyParser = require('body-parser');
var socketio = require('socket.io');
var mysql = require('mysql');

var connection = mysql.createConnection({
    host : '127.0.0.1',
    user : 'root',
    password : 'wlvlwlrl87!',
    database : 'chatapp'
});
connection.connect();
console.log('OS NETWORK INTERFACES : ');
console.dir(os.networkInterfaces());


var app = express();

//미들 웨어를 설정합니다.
app.use(express.static(__dirname + '/public'));
//app.use(express.static(__filename + '/public'));
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use(cookieParser());
app.use(session({secret: 'multi vision unicorns'}));
/*
app.use(function (request, response) {
    fs.readFile('index.html', 'utf8', function (error, data){
        response.writeHead(200, {'Content-Type': 'text/html'});
        response.end(data);
    });
});
*/

app.route('/:room/:id')
    .get(function(request, response, next){
        fs.readFile('HTMLPage.htm', 'utf8', function (error, data){
            var id = request.param('id');
            var room = request.param('room');
            response.writeHead(200, {'Content-Type':'text/html'});
            //response.end(data);
            var get_chat;
            var sql = "SELECT * FROM chat WHERE room = ?";
            connection.query(sql, [room], function(err, rows, fields){
                if (err){
                    throw err;
                }
                else{
                    get_chat = rows;
                    // end response after db query
                    response.end(ejs.render(data, {
                        id : id,
                        room : room,
                        get_chat : get_chat
                    }));
                }
            });
        });
    })
    .post(function(request, response, next){

    });

app.route('/msg')
    .get(function(request, response, next){
        var result = [];
        /*
        for (var name in goals) {
          if (goals.hasOwnProperty(name)) {
            result.push({name: name, goals: goals[name]});
          }
        }
        */
        result.push({name: "1번 이름", msg : "1번 문자열"});
        result.push({name: "2번 이름", msg : "2번 문자열"});
        result.push({name: "3번 이름", msg : "3번 문자열"});
        response.setHeader('Content-Type', 'application/json; charset=utf8');
        response.end(JSON.stringify(result));
    })
    .post(function(request, response, next){

    });

//웹 서버를 생성하고 실행
var app_soc = http.createServer(app).listen(52273, function (request, response) {
    console.log('Server running at http://127.0.0.1:52273');
});

var requestNum = 0;
app_soc.on('request', function (request, response) {
    console.log('requestNum = ' + requestNum++);
});
app_soc.on('close', function(){
    console.log('close');
});

//웹 소캣 서버 생성
var io = socketio.listen(app_soc);
io.sockets.on('connection', function(socket, response){
    // setname 이벤트 발생
    socket.on('users', function(data){
        // 클라이언트 데이터 저장 (room, id)
        socket.join(data.room);
        socket.set('room', data.room);
        socket.set('id', data.id);
    });

    // room, id, message, type, time, date
    socket.on('message', function(data){
        if(data.message != ""){
            socket.get('room', function (error, room){
                io.sockets.in(room).emit('message',data);
            });
            console.log("GET MESSAGE : " + data.message);
            console.log("GET TYPE : " + data.type);

            connection.query('INSERT INTO chat (room, id, message, type, time) VALUES (?, ?, ?, ?, ?)',
                [data.room, data.id, data.message, data.type, data.date]);
        }
    });


    socket.on('disconnect', function(){
        socket.get('room', function (error, room){
            socket.get('id', function (error, id){
            });
        });
    });
});
