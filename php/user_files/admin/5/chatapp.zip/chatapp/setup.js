// 모듈 추출
var mysql = require('mysql');

var connection = mysql.createConnection({
	host : '127.0.0.1',
	user : 'root',
	password : 'wlvlwlrl87!',
	database : 'chatapp'
});
connection.connect();

// room, id, message, type, time

// 상대 방에 대화
connection.query('CREATE table chat(' +
    'room VARCHAR(32), ' +
    'id VARCHAR(32), ' +
    'message VARCHAR(128), ' +
    'type integer, ' +
    'time VARCHAR(16))'
    );

// 나에 대한 방 정리
connection.query('CREATE table room (' +
    'room VARCHAR(32), ' +
    'id VARCHAR(32), ' +
    'primary key(room, id))');
/*
connection.query('CREATE table member (phone VARCHAR(16), id VARCHAR(32), otv VARCHAR(32), setting VARCHAR(1))');
connection.query('CREATE table friend (phone VARCHAR(16), friend VARCHAR(32), friend_phone VARCHAR(16))');
*/
connection.end();
