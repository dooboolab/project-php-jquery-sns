package org.blackpearl.blackmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.blackpearl.blackmarket.data.AccessDB;
import org.blackpearl.blackmarket.network.NetworkPreference;
import org.blackpearl.blackmarket.task.SetNameTask;
import org.json.JSONArray;
import org.json.JSONObject;

public class SetNameActivity extends Activity implements View.OnClickListener {

    private static String TAG = "SetNameActivity";

    // ui
    TextView phoneText;
    EditText nameEditText;
    Button btnOk;
    Button btnCancel;

    SetNameTask setNameTask;

    String phone = null;
    String name = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_setname);

        Intent intent = getIntent();
        phone = intent.getExtras().getString("phone");
        //AccessDB.getInstance(this)

        // init ui
        phoneText = (TextView) findViewById(R.id.phoneText);
        nameEditText = (EditText) findViewById(R.id.nameEditText);
        btnOk = (Button) findViewById(R.id.btnOk);
        btnCancel = (Button) findViewById(R.id.btnCancel);

        // set ui
        phoneText.setText(phone);


        btnOk.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnOk:
                name = nameEditText.getText().toString();
                if(name.equals("") || name == null){
                    Toast toast = Toast.makeText(getApplicationContext(), "이름을 입력해주세요", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 600);
                    toast.show();
                    return;
                } else{
                    // 접속 URL
                    String strUrl = NetworkPreference.getInstance(this).getServer_url() + "/newuser";
                    Log.i(TAG, "url : " + strUrl);
                    setNameTask = new SetNameTask(SetNameActivity.this, phone, name);
                    setNameTask.setOnResultListener(getNameResult);
                    setNameTask.execute(strUrl);
                }
                break;
            case R.id.btnCancel:
                Intent returnIntent = new Intent();
                setResult(RESULT_CANCELED,returnIntent);
                finish();
                break;
        }

    }

    SetNameTask.GetNameResult getNameResult = new SetNameTask.GetNameResult() {
        @Override
        public void onResultSuccess(final int resultCode, final String message) {
            Log.i(TAG, "onResultSuccess - code : " + resultCode + "\n" + message);

            int server_number = 0;
            String server_name = null;
            String server_phone = null;
            // 서버로 이름 송수신 성공
            // Json Parse
            try {
                JSONArray json = new JSONArray(message);
                JSONObject json_obj = json.getJSONObject(0);

                server_phone = json_obj.getString("phone");
                server_name = json_obj.getString("name");
                server_number = json_obj.getInt("number");

            }catch (Exception e){
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            } finally{
                AccessDB.getInstance(SetNameActivity.this).insertManager(
                        server_number,
                        server_name,
                        server_phone,
                        0,
                        "N",
                        null,
                        null,
                        null
                );
            }

            Log.i(TAG, "phone : " + server_phone + ", name : " + server_name + ", number : " + server_number);

            // server로 부터 number를 받았으면 LoadingActivity로 돌아감
            Intent returnIntent = new Intent();
            setResult(RESULT_OK, returnIntent);
            Log.i(TAG, "setResult : 1");
            finish();
        }

        @Override
        public void onResultFail(final int resultCode, final String errorMessage) {
            Log.i(TAG, "onResultFail - code : " + resultCode + "\n" + errorMessage);
            setNameTask.cancel(true);
            // 서버로 이름 전송 실패
            runOnUiThread(new Runnable(){
                public void run(){
                    //다이얼로그 띄우기
                    AlertDialog.Builder builder = new AlertDialog.Builder(SetNameActivity.this);
                    // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                    builder.setTitle("네트워크 오류"); // 제목
                    builder.setMessage("네트워크에 인증에 실패하였습니다. 나중에 다시 이용해주세요."); // 메시지
                    builder.setCancelable(false);
                    builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();     //닫기
                            //finish();
                        }
                    });
                    builder.show();
                }
            });
        }
    };

    // 외부 클릭시 없어지는 현상 막기
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //return super.onTouchEvent(event);
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.setname, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
