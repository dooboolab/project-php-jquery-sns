package org.blackpearl.blackmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.blackpearl.blackmarket.network.NetworkPreference;
import org.blackpearl.blackmarket.task.AddMarketTask;
import org.blackpearl.blackmarket.task.GetIdTask;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AddMarketActivity extends Activity implements View.OnClickListener, AdapterView.OnItemSelectedListener{


    //commit test


    private final String TAG = "AddMarketActivity";

    Button btnCancel;
    Button btnOK;

    // 5 EditText, 1 Spinner
    EditText marketName;
    Spinner spinnerCategory;
    EditText phone;
    EditText address;
    EditText homepage;
    EditText main_product;

    ArrayList<SpinnerItems> items;
    int item_position = 0;

    AddMarketTask addMarketTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_market);

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnOK = (Button) findViewById(R.id.btnOK);

        btnCancel.setOnClickListener(this);
        btnOK.setOnClickListener(this);



        marketName= (EditText) findViewById(R.id.editText_marketName);
        spinnerCategory = (Spinner) findViewById(R.id.spinner_category);
        phone = (EditText) findViewById(R.id.editText_phone);
        address = (EditText) findViewById(R.id.editText_address);
        homepage = (EditText) findViewById(R.id.editText_homepage);
        main_product = (EditText) findViewById(R.id.editText_mainProduct);

        ArrayList<SpinnerItems> list = new ArrayList<SpinnerItems>();
        list.add(new SpinnerItems(R.drawable.icon_wear, "의류"));
        list.add(new SpinnerItems(R.drawable.icon_food,"음식점"));
        list.add(new SpinnerItems(R.drawable.icon_hair, "미용실"));
        list.add(new SpinnerItems(R.drawable.icon_hospital, "병원/약국"));
        list.add(new SpinnerItems(R.drawable.icon_beauty, "화장품"));
        list.add(new SpinnerItems(R.drawable.icon_sing, "노래방"));
        list.add(new SpinnerItems(R.drawable.icon_pc, "컴퓨터"));
        list.add(new SpinnerItems(R.drawable.icon_coffee, "커피"));
        list.add(new SpinnerItems(R.drawable.icon_drink, "술"));
        SpinnerAdapter spinner_adapter = new SpinnerAdapter(this,
                R.layout.spinner_category, R.id.spinner_name, list);
        spinnerCategory.setAdapter(spinner_adapter);
        spinnerCategory.setOnItemSelectedListener(this);


    }

    // data for spinner adapter
    private class SpinnerItems{
        int image;
        String name;
        boolean checked;

        private SpinnerItems(int image, String name) {
            this.image = image;
            this.name = name;
            this.checked = false;
        }

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isChecked() {
            return checked;
        }

        public void setChecked(boolean checked) {
            this.checked = checked;
        }
    }

    // Adapter class for spinner
    private class ViewHolder{
        public TextView text;
        public ImageView image;
        public ImageView checked;
    }

    private class SpinnerAdapter extends ArrayAdapter<SpinnerItems>{

        public SpinnerAdapter(Context context, int resource, int textViewResourceId, ArrayList<SpinnerItems> objects) {
            super(context, resource, textViewResourceId, objects);
            items = objects;
        }

        // spinner에서 클릭했을 때 리스트로 펼쳐지는 화면
        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            /*
            LayoutInflater inflater=getLayoutInflater();
            convertView=inflater.inflate(R.layout.spinner_category, parent, false);

            ImageView image = (ImageView) convertView.findViewById(R.id.spinner_img);
            TextView name = (TextView) convertView.findViewById(R.id.spinner_name);
            image.setImageResource(items.get(position).getImage());
            name.setText(items.get(position).getName());

            Log.i(TAG, items.get(position).getName());

            */
            return getCustomView(position, convertView, parent);
        }

        // spinner에서 항목을 선택했을 때 나오는 화면
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            for(int i=0; i<items.size(); i++){
                items.get(i).setChecked(false);
            }
            items.get(position).setChecked(true);
            item_position = position;
            return getCustomView(position, convertView, parent);
        }

        public View getCustomView(int position, View convertView, ViewGroup parent){

            ViewHolder viewHolder;

            if(convertView == null){
                LayoutInflater inflater=getLayoutInflater();
                convertView=inflater.inflate(R.layout.spinner_category, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.image = (ImageView) convertView.findViewById(R.id.spinner_img);
                viewHolder.text = (TextView) convertView.findViewById(R.id.spinner_name);
                viewHolder.checked = (ImageView) convertView.findViewById(R.id.spinner_checked);
                convertView.setTag(viewHolder);
            } else{
                viewHolder = (ViewHolder) convertView.getTag();
            }
            // ImageView image = (ImageView) convertView.findViewById(R.id.spinner_img);
            // TextView name = (TextView) convertView.findViewById(R.id.spinner_name);
            // ImageView checked = (ImageView) convertView.findViewById(R.id.spinner_checked);
            viewHolder.image.setImageResource(items.get(position).getImage());
            viewHolder.text.setText(items.get(position).getName());

            if(items.get(position).isChecked() == true){
                viewHolder.checked.setVisibility(View.VISIBLE);
            }else{
                viewHolder.checked.setVisibility(View.INVISIBLE);
            }
            return convertView;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnCancel:
                finish();
                break;
            case R.id.btnOK:
                if(marketName.getText().toString().equals("") || phone.getText().toString().equals("") || address.getText().toString().equals("")
                        || homepage.getText().toString().equals("") || main_product.getText().toString().equals("")) {
                    Toast toast = Toast.makeText(this, "마켓을 등록하시려면 모든 정보를 입력해주셔야 합니다.", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.TOP, 0, 800);
                    toast.show();
                } else if(marketName.getText().toString().equals("null")){
                    Toast toast = Toast.makeText(this, "마켓명이 null이 될 수 없습니다.", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.TOP, 0, 800);
                    toast.show();
                }
                else{
                    // get ID from server
                    String strUrl = NetworkPreference.getInstance(this).getServer_url() + "/getid";
                    Log.i(TAG, "url : " + strUrl);
                        /*
                         1. GetIdTask를 통해 서버로부터 회원 아이디를 받아온다.
                         2. 아이디가 없으면 아이디를 입력하라는 화면이 나온다.
                         3. 아이디가 있으면 AddMarketTask를 불러서 마켓을 서버에 등록한다.
                         */
                    GetIdTask getIdTask = new GetIdTask(AddMarketActivity.this);
                    getIdTask.setOnResultListener(getIdResult);
                    getIdTask.execute(strUrl);
                }
                break;
            default:
                break;
        }
    }

    String server_phone = null;
    String server_id= null;

    GetIdTask.GetIdResult getIdResult  = new GetIdTask.GetIdResult(){
        @Override
        public void onResultSuccess(int resultCode, String message) {
            Log.i(TAG, "onResultSuccess - code : " + resultCode + "\n" + message);
            // 서버로 이름 송수신 성공
            // Json Parse
            try {
                JSONArray json = new JSONArray(message);
                JSONObject json_obj = json.getJSONObject(0);
                server_phone = json_obj.getString("phone");
                server_id = json_obj.getString("id");

                Log.i("TAG", "get phone from server : " + server_phone);
                Log.i("TAG", "get ID from server : " + server_id);
            }catch (Exception e){
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            }
            // 서버가 phone 값을 못받았으면 전화번호 오류
            if(server_phone == null || server_phone.equals("null") || server_phone.equals("")){
                Log.i(TAG, "server phone is null");
                if(AddMarketActivity.this != null && !AddMarketActivity.this.isFinishing()){
                    runOnUiThread(new Runnable() {
                        public void run() {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(AddMarketActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("전화번호 오류"); // 제목
                            builder.setMessage("전화번호 오류가 발생했습니다. 앱을 새로 시작해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    //finish();
                                }
                            });
                            builder.show();
                        }
                    });
                    finish();
                }
            }
            // phone에 대한 아이다가 존재 하지 않음
            else if(server_id.equals("null") || server_id.equals("")){
                Log.i(TAG, "id not exists");
                if(AddMarketActivity.this != null && !AddMarketActivity.this.isFinishing()) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(AddMarketActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("아이디 오류"); // 제목
                            builder.setMessage("마켓을 등록하려면 아이디를 만들어야 합니다. 아이디를 생성 후 다시 이용해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    //finish();
                                }
                            });
                            builder.show();
                        }
                    });
                    finish();
                }
            }
            // id가 존재함
            else{
                Log.i(TAG, "id exists");
                Log.i(TAG, "market name : " + marketName.getText());
                Log.i(TAG, "item position : " + item_position);
                Log.i(TAG, "phone : " + phone.getText());
                Log.i(TAG, "address : " + address.getText());
                Log.i(TAG, "homepage : " + homepage.getText());
                Log.i(TAG, "main_product : " + main_product.getText());


                // get ID from server
                String strUrl = NetworkPreference.getInstance(AddMarketActivity.this).getServer_url() + "/addmarket";
                Log.i(TAG, "url : " + strUrl);
                /*
                     1. GetIdTask를 통해 서버로부터 회원 아이디를 받아온다. ==> done
                     2. 아이디가 없으면 아이디를 입력하라는 화면이 나온다. ==> done
                     3. 아이디가 있으면 AddMarketTask를 불러서 마켓을 서버에 등록한다. ==> start
                 */
                // 아이디가 존재하니 addMarketTask 실행
                addMarketTask = new AddMarketTask(AddMarketActivity.this,
                        server_id,
                        marketName.getText().toString(),
                        items.get(item_position).getName(),
                        phone.getText().toString(),
                        address.getText().toString(),
                        homepage.getText().toString(),
                        main_product.getText().toString()
                );
                addMarketTask.setOnResultListener(addMarketResult);
                addMarketTask.execute(strUrl);
            }

        }

        @Override
        public void onResultFail(int resultCode, String errorMessage) {
            Log.i(TAG, "getId result fails");
            if(AddMarketActivity.this != null && !AddMarketActivity.this.isFinishing()){
                runOnUiThread(new Runnable(){
                    public void run(){
                        //다이얼로그 띄우기
                        AlertDialog.Builder builder = new AlertDialog.Builder(AddMarketActivity.this);
                        // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                        builder.setTitle("알수없는 오류 오류"); // 제목
                        builder.setMessage("알 수 없는 오류가 발생했습니다. 어플리케이션을 새로 시작해주세요."); // 메시지
                        builder.setCancelable(false);
                        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();     //닫기
                                //finish();
                            }
                        });
                        builder.show();
                    }
                });
                finish();
            }
        }
    };

    AddMarketTask.AddMarketResult addMarketResult = new AddMarketTask.AddMarketResult(){
        @Override
        public void onResultSuccess(int resultCode, String message) {
            Log.i(TAG, "addmarket result success");
            String marketName = null;
            try {
                JSONArray json = new JSONArray(message);
                JSONObject json_obj = json.getJSONObject(0);
                marketName = json_obj.getString("marketName");

                Log.i("TAG", "get marketName : " + marketName);
            }catch (Exception e){
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            }

            // marketName exists on server try another name
            if(marketName == null || marketName.equals("") || marketName.equals("null")){
                Toast toast = Toast.makeText(AddMarketActivity.this, "마켓이름이 이미 존재합니다. 다른 이름으로 시도해주세요.", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP, 0, 800);
                toast.show();
            }
        }

        @Override
        public void onResultFail(int resultCode, String errorMessage) {
            Log.i(TAG, "addmarket result fails");
            if(AddMarketActivity.this != null && !AddMarketActivity.this.isFinishing()) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (AddMarketActivity.this != null && !AddMarketActivity.this.isFinishing()) {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(AddMarketActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("알수없는 오류 오류"); // 제목
                            builder.setMessage("알 수 없는 오류가 발생했습니다. 어플리케이션을 새로 시작해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    //finish();
                                }
                            });
                            builder.show();
                        }
                    }
                });
                finish();
            }
        }
    };

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (view.getId()){
            case R.id.spinner_category:

                Log.i(TAG, "name : " + items.get(position).getName());
                break;
            default:
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_market, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
