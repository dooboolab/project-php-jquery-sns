package org.blackpearl.blackmarket.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.blackpearl.blackmarket.data.ManagerPreference;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014. 8. 16..
 */
public class SetNameTask extends AsyncTask<String, Integer, String> {

    private static final String TAG = "SetNameTask";
    GetNameResult getNameResult;
    Context mContext;
    String phone;
    String name;

    public SetNameTask (Context context, String phone, String name){
        mContext = context;
        this.phone = phone;
        this.name = name;

    }

    public void setOnResultListener(GetNameResult getNameResult){
            if(getNameResult != null){
                this.getNameResult = getNameResult;
            }
    }

    @Override
    protected void onCancelled() {
            super.onCancelled();
            }

    @Override
    protected void onPreExecute() {
            super.onPreExecute();
            }

    @Override
    protected String doInBackground(String... url) {
            // 서버에 전달할 파라메터 세팅
            ArrayList<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
            if(ManagerPreference.getInstance(mContext).getNumber() != 0)
                nameValuePairs.add(new BasicNameValuePair("number", ManagerPreference.getInstance(mContext).getNumber() + ""));
            nameValuePairs.add(new BasicNameValuePair("name", name));
            nameValuePairs.add(new BasicNameValuePair("phone", phone));

            Log.i(TAG, "name : " + phone);
            Log.i(TAG, "phone : " + name);

            String result = "";
            try {
                HttpClient http = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost(url[0]);
                UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
                httpPost.setEntity(entityRequest);
                HttpResponse response = http.execute(httpPost);
                result = EntityUtils.toString(response.getEntity());
            } catch (Exception e) {
                e.printStackTrace();
                getNameResult.onResultFail(0, "받아오질 못했네요...");
            }
            return result;
            }

    //get the returned text from the url
    @Override
    protected void onPostExecute(String result){
            Log.i(TAG, "result : " + result);
            if(result.equals("") == false || result != null) {
                if (getNameResult != null) {
                    getNameResult.onResultSuccess(1, result);
                }
            }
    }

    public interface GetNameResult {
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }
}
