package org.blackpearl.blackmarket.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.blackpearl.blackmarket.R;
import org.blackpearl.blackmarket.data.MarketCategoryData;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014. 8. 14..
 */
public class HomeCategoryAdapter extends BaseAdapter {

    Context mContext;
    int layout;
    ArrayList<MarketCategoryData> list;
    LayoutInflater inflater;
    private ViewHolder viewHolder;

    class ViewHolder
    {
        public ImageView image;
        public TextView text;
    }

    public HomeCategoryAdapter(Context context, int layout, ArrayList<MarketCategoryData> list) {
        mContext = context;
        this.layout = layout;
        this.list = list;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if(v == null){
            viewHolder = new ViewHolder();
            v = inflater.inflate(R.layout.left_menu_list, null);
            viewHolder.image = (ImageView)v.findViewById(R.id.category_img);
            viewHolder.text = (TextView)v.findViewById(R.id.category_name);
            v.setTag(viewHolder);

        }else {
            viewHolder = (ViewHolder)v.getTag();
        }

        viewHolder.text.setText(list.get(position).getName());
        viewHolder.image.setImageResource(list.get(position).getImage());

        return v;
    }
}
