package org.blackpearl.blackmarket.animation;

import android.view.Gravity;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/**
 * Created by hyochan on 2014. 8. 2..
 */
public class OpenAnimation extends TranslateAnimation implements
        Animation.AnimationListener {

    private RelativeLayout RelLayout;
    private LinearLayout LinLayout;
    int panelWidth;

    public OpenAnimation(int width,
                         int fromXType, float fromXValue,
                         int toXType, float toXValue,
                         int fromYType, float fromYValue,
                         int toYType, float toYValue, RelativeLayout relLayout, LinearLayout linLayout) {

        super(fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue,
                toYType, toYValue);

        // init
        RelLayout = relLayout;
        LinLayout = linLayout;
        panelWidth = width;
        setDuration(250);
        setFillAfter(true);
        setInterpolator(new AccelerateDecelerateInterpolator());
        setAnimationListener(this);
        if(relLayout != null) {
            relLayout.startAnimation(this);
        }
        else if(linLayout != null){
            linLayout.startAnimation(this);
        }
    }

    public void onAnimationEnd(Animation arg0) {

        //params.gravity = Gravity.LEFT;
        if(RelLayout != null) {
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) RelLayout.getLayoutParams();
            params.leftMargin = panelWidth;
            params.rightMargin -= panelWidth;
            RelLayout.clearAnimation();
            RelLayout.setLayoutParams(params);
            RelLayout.setGravity(Gravity.LEFT);
            RelLayout.requestLayout();
        }
        else if(LinLayout != null){
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) LinLayout.getLayoutParams();
            params.leftMargin = panelWidth;
            params.rightMargin -= panelWidth;
            LinLayout.clearAnimation();
            LinLayout.setLayoutParams(params);
            LinLayout.setGravity(Gravity.LEFT);
            LinLayout.requestLayout();
        }

    }

    public void onAnimationRepeat(Animation arg0) {

    }

    public void onAnimationStart(Animation arg0) {

    }

}