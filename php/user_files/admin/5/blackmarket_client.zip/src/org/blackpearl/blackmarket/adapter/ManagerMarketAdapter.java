package org.blackpearl.blackmarket.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.blackpearl.blackmarket.R;
import org.blackpearl.blackmarket.data.ManagerMarketPreference;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014-09-10.
 */
public class ManagerMarketAdapter extends ArrayAdapter<ManagerMarketPreference>{


    private final String TAG = "ManagerMarketAdapter";
    Context context;
    ArrayList<ManagerMarketPreference> arrayList;


    public ManagerMarketAdapter(Context context, int resource, int textViewResourceId, ArrayList<ManagerMarketPreference> arrayList) {
        super(context, resource, textViewResourceId, arrayList);
        this.context = context;
        this.arrayList = arrayList;
    }

    class ViewHolder{
        public ImageView image;
        public TextView name;
        public TextView msg;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null){
            LayoutInflater inflater=LayoutInflater.from(context);
            convertView=inflater.inflate(R.layout.manager_market_list, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.image = (ImageView) convertView.findViewById(R.id.market_image);
            viewHolder.name = (TextView) convertView.findViewById(R.id.market_name);
            viewHolder.msg = (TextView) convertView.findViewById(R.id.market_msg);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Log.i(TAG, "position : " + position + ", name : " + arrayList.get(position).getName());
        viewHolder.name.setText(arrayList.get(position).getName());

        return convertView;


    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }
}
