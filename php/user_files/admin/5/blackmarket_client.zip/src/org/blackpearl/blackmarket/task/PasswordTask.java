package org.blackpearl.blackmarket.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014. 8. 16..
 */
public class PasswordTask extends AsyncTask<String, Integer, String> {

    private static final String TAG = "PasswordTask";
    GetPasswordResult getPasswordResult;
    Context mContext;
    String id;
    String password;

    public PasswordTask (Context context, String id, String password){
        mContext = context;
        this.id = id;
        this.password = password;

    }

    public void setOnResultListener(GetPasswordResult getPasswordResult){
        if(getPasswordResult != null){
            this.getPasswordResult = getPasswordResult;
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... url) {
        // 서버에 전달할 파라메터 세팅
        ArrayList<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
        if(password == null) {
            nameValuePairs.add(new BasicNameValuePair("id", id));
        } else{
            nameValuePairs.add(new BasicNameValuePair("id", id));
            nameValuePairs.add(new BasicNameValuePair("password", password));
        }

        Log.i(TAG, "id : " + id);
        Log.i(TAG, "password : " + password);

        String result = "";
        try {
            HttpClient http = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url[0]);
            UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
            httpPost.setEntity(entityRequest);
            HttpResponse response = http.execute(httpPost);
            result = EntityUtils.toString(response.getEntity());
        } catch (Exception e) {
            e.printStackTrace();
            getPasswordResult.onResultFail(0, "받아오질 못했네요...");
        }
        return result;
    }

    // get the returned text from the url
    @Override
    protected void onPostExecute(String result){
        Log.i(TAG, "result : " + result);
        if(result.equals("") == false || result != null) {
            if (getPasswordResult != null) {
                getPasswordResult.onResultSuccess(1, result);
            }
        }
    }

    public interface GetPasswordResult {
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }
}
