package org.blackpearl.blackmarket.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.blackpearl.blackmarket.data.ManagerPreference;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014-09-10.
 */
public class GetIdTask extends AsyncTask<String, Integer, String> {

    private final String TAG = "GetIdTask";

    Context context;

    GetIdResult getIdResult;

    public void setOnResultListener(GetIdResult getIdResult){
        if(getIdResult != null){
            this.getIdResult = getIdResult;
        }
    }

    public GetIdTask(Context context) {
        super();
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        if(getIdResult != null){
            Log.i(TAG, "resultSuccess");
            getIdResult.onResultSuccess(1, result);
        }
    }

    public interface GetIdResult{
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }

    @Override
    protected void onCancelled(String s) {
        super.onCancelled(s);
    }

    @Override
    protected String doInBackground(String... url) {

        String result = null;

        ArrayList<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("phone", ManagerPreference.getInstance(context).getPhone()));
        Log.i(TAG, "phone : " + ManagerPreference.getInstance(context).getPhone());

        try {
            HttpClient http = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url[0]);
            UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
            httpPost.setEntity(entityRequest);
            HttpResponse response = http.execute(httpPost);
            result = EntityUtils.toString(response.getEntity());
        } catch (Exception e) {
            e.printStackTrace();
            getIdResult.onResultFail(0, "받아오질 못했네요...");
        }
        Log.i(TAG, "background result : " + result);
        return result;
    }
}
