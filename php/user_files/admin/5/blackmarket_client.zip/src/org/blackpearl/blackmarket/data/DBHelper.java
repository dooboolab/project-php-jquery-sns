package org.blackpearl.blackmarket.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by hyochan on 2014. 8. 15..
 */
public class DBHelper extends SQLiteOpenHelper {  //데이터베이스 클래스

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                    int version) {
        super(context, name, factory, version);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("CREATE TABLE market(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "number INTEGER" +
                "name TEXT, " +
                "category TEXT, " +
                "phone TEXT, " +
                "address TEXT, " +
                "homepage TEXT, " +
                "manager TEXT, " +
                "rating INTEGER, " +
                "avg_price INTEGER, " +
                "image INTEGER, " +
                "movie INTEGER, " +
                "time datetime" +
                ");");

        db.execSQL("CREATE TABLE manager(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "number INTEGER" +
                "name TEXT, " +
                "phone TEXT, " +
                "market INTEGER, " +
                "image INTEGER, " +
                "email TEXT, " +
                "id TEXT, " +
                "password TEXT " +
                ");");

        db.execSQL("CREATE TABLE owns(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "manager TEXT, " +
                "market INTEGER " +
                ");");

        db.execSQL("CREATE TABLE setting(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "registered INTEGER, " +
                "fragment INTEGER " +
                ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXIST market;");
        db.execSQL("DROP TABLE IF EXIST manager;");
        db.execSQL("DROP TABLE IF EXIST owns;");
        onCreate(db);
    }

}