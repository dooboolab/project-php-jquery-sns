package org.blackpearl.blackmarket;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.blackpearl.blackmarket.data.AccessDB;
import org.blackpearl.blackmarket.data.ManagerPreference;
import org.blackpearl.blackmarket.fragment.FavoriteFragment;
import org.blackpearl.blackmarket.fragment.HomeFragment;
import org.blackpearl.blackmarket.fragment.ManagerFragment;


public class MainActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    int mCurrentFragmentIndex;
    public final static int FRAGMENT_ONE = 0;
    public final static int FRAGMENT_TWO = 1;
    public final static int FRAGMENT_THREE = 2;

    public static boolean isLeftExpanded;

    RelativeLayout btn_home_fragment;
    RelativeLayout btn_favorite_fragment;
    RelativeLayout btn_manager_fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toast toast = Toast.makeText(getApplicationContext(),
                ManagerPreference.getInstance(MainActivity.this).getName() +
                        "님 환영합니다.", Toast.LENGTH_SHORT);
        //toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 600);
        toast.show();


        closeMenu();

        btn_home_fragment = (RelativeLayout) findViewById(R.id.btn_home_fragment);
        btn_favorite_fragment = (RelativeLayout) findViewById(R.id.btn_favorite_fragment);
        btn_manager_fragment = (RelativeLayout) findViewById(R.id.btn_manager_fragment);

        btn_home_fragment.setOnClickListener(this);
        btn_favorite_fragment.setOnClickListener(this);
        btn_manager_fragment.setOnClickListener(this);

        mCurrentFragmentIndex = AccessDB.getInstance(MainActivity.this).getSettingFragment();
        fragmentReplace(mCurrentFragmentIndex);
        if(mCurrentFragmentIndex == 0)
            btn_home_fragment.setSelected(true);
        else if(mCurrentFragmentIndex == 1)
            btn_favorite_fragment.setSelected(true);
        else if(mCurrentFragmentIndex == 2)
            btn_manager_fragment.setSelected(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // set the last fragment
        Log.i(TAG, "stopped : " + mCurrentFragmentIndex);
        AccessDB.getInstance(MainActivity.this).updateSettingFragment(mCurrentFragmentIndex);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void fragmentReplace(int reqNewFragmentIndex) {

        Fragment newFragment = null;
        newFragment = getFragment(reqNewFragmentIndex);

        Log.i(TAG, "current : " + mCurrentFragmentIndex + ", replace : " + reqNewFragmentIndex);
        // replace fragment
        //final FragmentTransaction transaction = this.getFragmentManager().beginTransaction();
        //transaction.replace(R.id.ll_fragment, newFragment);
        //transaction.commit();
        FragmentTransaction ft = this.getFragmentManager().beginTransaction();
        if(mCurrentFragmentIndex < reqNewFragmentIndex){
            ft.setCustomAnimations(R.anim.fragment_anim_right_in, R.anim.fragment_anim_left_out);
        }else if(mCurrentFragmentIndex > reqNewFragmentIndex){
            ft.setCustomAnimations(R.anim.fragment_anim_left_in, R.anim.fragment_anim_right_out);
        }
        ft.replace(R.id.ll_fragment, newFragment);
        ft.commit();
    }

    private Fragment getFragment(int idx) {
        Fragment newFragment = null;

        switch (idx) {
            case FRAGMENT_ONE:
                newFragment = new HomeFragment();
                break;
            case FRAGMENT_TWO:
                newFragment = new FavoriteFragment();
                break;
            case FRAGMENT_THREE:
                newFragment = new ManagerFragment();
                break;

            default:
                Log.i(TAG, "Unhandle case");
                break;
        }

        return newFragment;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btn_home_fragment:
                closeMenu();
                if(mCurrentFragmentIndex == FRAGMENT_THREE) {
                    fragmentReplace(FRAGMENT_TWO);
                    btn_manager_fragment.setSelected(false);
                    btn_favorite_fragment.setSelected(true);
                    btn_home_fragment.setSelected(false);
                    mCurrentFragmentIndex = FRAGMENT_TWO;
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable(){
                        @Override
                        public void run()
                        {
                            fragmentReplace(FRAGMENT_ONE);
                            btn_favorite_fragment.setSelected(false);
                            btn_manager_fragment.setSelected(false);
                            btn_home_fragment.setSelected(true);
                            mCurrentFragmentIndex = FRAGMENT_ONE;
                        }
                    }, 150);
                } else{
                    btn_favorite_fragment.setSelected(false);
                    btn_manager_fragment.setSelected(false);
                    btn_home_fragment.setSelected(true);
                    fragmentReplace(FRAGMENT_ONE);
                    mCurrentFragmentIndex = FRAGMENT_ONE;
                }
                break;
            case R.id.btn_favorite_fragment:
                closeMenu();
                fragmentReplace(FRAGMENT_TWO);
                mCurrentFragmentIndex = FRAGMENT_TWO;
                btn_favorite_fragment.setSelected(true);
                btn_home_fragment.setSelected(false);
                btn_manager_fragment.setSelected(false);
                break;
            case R.id.btn_manager_fragment:
                closeMenu();
                Handler mHandler = new Handler();
                if(mCurrentFragmentIndex == FRAGMENT_ONE) {
                    fragmentReplace(FRAGMENT_TWO);
                    mCurrentFragmentIndex = FRAGMENT_TWO;
                    btn_manager_fragment.setSelected(false);
                    btn_favorite_fragment.setSelected(true
                    );
                    btn_home_fragment.setSelected(false);
                    mHandler.postDelayed(new Runnable(){
                        @Override
                        public void run()
                        {
                            fragmentReplace(FRAGMENT_THREE);
                            mCurrentFragmentIndex = FRAGMENT_THREE;
                            btn_manager_fragment.setSelected(true);
                            btn_home_fragment.setSelected(false);
                            btn_favorite_fragment.setSelected(false);
                        }
                    }, 150);
                }else{
                    fragmentReplace(FRAGMENT_THREE);
                    mCurrentFragmentIndex = FRAGMENT_THREE;
                    btn_manager_fragment.setSelected(true);
                    btn_home_fragment.setSelected(false);
                    btn_favorite_fragment.setSelected(false);
                }
                break;
        }

    }

    private void closeMenu(){
        if(isLeftExpanded == true){
            //HomeFragment homeFragment = new HomeFragment();
            //homeFragment.menuLeftSlideAnimationToggle();
            isLeftExpanded = false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
