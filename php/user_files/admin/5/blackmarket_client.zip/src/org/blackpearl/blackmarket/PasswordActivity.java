package org.blackpearl.blackmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.blackpearl.blackmarket.data.AccessDB;
import org.blackpearl.blackmarket.network.NetworkPreference;
import org.blackpearl.blackmarket.task.PasswordTask;
import org.json.JSONArray;
import org.json.JSONObject;


public class PasswordActivity extends Activity implements View.OnClickListener{

    private static String TAG = "PasswordActivity";

    PasswordTask passwordTask;

    TextView IdText;
    EditText passwordEditText;
    Button btnNopassword;
    Button btnCancel;
    Button btnOk;

    String id;
    String password;

    private String strUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);


        strUrl = NetworkPreference.getInstance(this).getServer_url() + "/password";

        btnNopassword = (Button) findViewById(R.id.btnNopassword);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnOk = (Button) findViewById(R.id.btnOk);
        IdText = (TextView) findViewById(R.id.IdText);
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        IdText.setText(id);

        // set click listener
        btnNopassword.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        btnOk.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnNopassword :
                passwordTask = new PasswordTask(PasswordActivity.this, id, null);
                passwordTask.setOnResultListener(getPasswordResult);
                passwordTask.execute(strUrl);
                break;
            case R.id.btnOk:
                password = passwordEditText.getText().toString();
                if(password.equals("") || password == null){
                    Toast toast = Toast.makeText(getApplicationContext(), "암호를 입력해주세요", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 600);
                    toast.show();
                    return;
                } else{
                    // 접속 URL
                    String id = IdText.getText().toString();
                    Log.i(TAG, "url : " + strUrl);
                    passwordTask = new PasswordTask(PasswordActivity.this, id, password);
                    passwordTask.setOnResultListener(getPasswordResult);
                    passwordTask.execute(strUrl);
                }
                break;
            case R.id.btnCancel:
                Intent returnIntent = new Intent();
                setResult(RESULT_CANCELED,returnIntent);
                finish();
                break;
        }
    }

    PasswordTask.GetPasswordResult getPasswordResult = new PasswordTask.GetPasswordResult() {
        @Override
        public void onResultSuccess(final int resultCode, final String message) {
                       Log.i(TAG, "onResultSuccess - code : " + resultCode + "\n" + message);

            int server_number = 0;
            String server_name = null;
            String server_phone = null;
            int server_markets = 0;
            String server_image = null;
            String server_email = null;
            String server_id = null;
            String server_password = null;
            // 서버로 이름 송수신 성공
            // Json Parse
            try {
                JSONArray json = new JSONArray(message);
                JSONObject json_obj = json.getJSONObject(0);

                server_phone = json_obj.getString("phone");
                server_name = json_obj.getString("name");
                server_number = json_obj.getInt("number");
                server_markets = json_obj.getInt("markets");
                server_image = json_obj.getString("image");
                server_email = json_obj.getString("email");
                server_id = json_obj.getString("id");
                server_password = json_obj.getString("password");

            }catch (Exception e){
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            }
            if(server_number != 0 && server_number != -1) {
                AccessDB.getInstance(PasswordActivity.this).insertManager(
                        server_number,
                        server_name,
                        server_phone,
                        server_markets,
                        server_image,
                        server_email,
                        server_id,
                        server_password
                );
                // server로 부터 number를 받았으면 LoadingActivity로 돌아감
                Intent returnIntent = new Intent();
                returnIntent.putExtra("number", server_number);
                setResult(RESULT_OK, returnIntent);
                Log.i(TAG, "setResult : 1");
                finish();
            }
            // user select not getting data => go back to LoadingActivity and start SetNameActivity
            else if(server_number == 0){
                Intent returnIntent = new Intent();
                returnIntent.putExtra("number", server_number);
                setResult(RESULT_OK, returnIntent);
                Log.i(TAG, "setResult : 1");
                finish();
            }
            // password not match
            else{
                runOnUiThread(new Runnable(){
                    public void run(){
                        //다이얼로그 띄우기
                        AlertDialog.Builder builder = new AlertDialog.Builder(PasswordActivity.this);
                        // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                        builder.setTitle("패스워드 오류"); // 제목
                        builder.setMessage("패스워드가 일치하지 않습니다. 다시 시도해주세요."); // 메시지
                        builder.setCancelable(false);
                        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();     //닫기
                                //finish();
                            }
                        });
                        builder.show();
                    }
                });
            }

        }

        @Override
        public void onResultFail(final int resultCode, final String errorMessage) {
            Log.i(TAG, "onResultFail - code : " + resultCode + "\n" + errorMessage);
            passwordTask.cancel(true);
            // 서버로 이름 전송 실패
            runOnUiThread(new Runnable(){
                public void run(){
                    //다이얼로그 띄우기
                    AlertDialog.Builder builder = new AlertDialog.Builder(PasswordActivity.this);
                    // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                    builder.setTitle("네트워크 오류"); // 제목
                    builder.setMessage("네트워크에 인증에 실패하였습니다. 나중에 다시 이용해주세요."); // 메시지
                    builder.setCancelable(false);
                    builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();     //닫기
                            //finish();
                        }
                    });
                    builder.show();
                }
            });
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.password, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
