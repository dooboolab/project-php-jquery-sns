package org.blackpearl.blackmarket.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.blackpearl.blackmarket.data.ManagerPreference;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014-09-10.
 */
public class AddMarketTask extends AsyncTask<String, Integer, String> {
    private static final String TAG = "AddMarketTask";

    Context context;
    String id;
    String marketName;
    String category;
    String phone;
    String address;
    String homepage;
    String main_product;

    AddMarketResult addMarketResult;

    public void setOnResultListener(AddMarketResult addMarketResult){
        if(addMarketResult != null){
            this.addMarketResult = addMarketResult;
        }
    }

    public AddMarketTask(Context context, String id, String marketName, String category, String phone, String address, String homepage, String main_product) {
        super();
        this.context = context;
        this.id = id;
        this.marketName = marketName;
        this.category = category;
        this.phone = phone;
        this.address = address;
        this.homepage = homepage;
        this.main_product = main_product;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        if(addMarketResult != null){
            addMarketResult.onResultSuccess(1, result);
        }
    }

    public interface AddMarketResult{
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }

    @Override
    protected void onCancelled(String s) {
        super.onCancelled(s);
    }

    @Override
    protected String doInBackground(String... url) {

        String result = null;

        ArrayList<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("id", id));
        nameValuePairs.add(new BasicNameValuePair("marketName", marketName));
        nameValuePairs.add(new BasicNameValuePair("category", category));
        nameValuePairs.add(new BasicNameValuePair("phone", phone));
        nameValuePairs.add(new BasicNameValuePair("address", address));
        nameValuePairs.add(new BasicNameValuePair("homepage", homepage));
        nameValuePairs.add(new BasicNameValuePair("main_product", main_product));
        Log.i(TAG, "id : " + id);
        try {
            HttpClient http = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url[0]);
            UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
            httpPost.setEntity(entityRequest);
            HttpResponse response = http.execute(httpPost);
            result = EntityUtils.toString(response.getEntity());
        } catch (Exception e) {
            e.printStackTrace();
            addMarketResult.onResultFail(0, "받아오질 못했네요...");
        }
        return result;
    }
}
