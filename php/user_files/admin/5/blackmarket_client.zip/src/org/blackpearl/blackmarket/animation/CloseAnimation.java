package org.blackpearl.blackmarket.animation;

import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/**
 * Created by hyochan on 2014. 8. 2..
 */
public class CloseAnimation extends TranslateAnimation implements
        TranslateAnimation.AnimationListener {

    private RelativeLayout RelLayout;
    private LinearLayout LinLayout;
    int panelWidth;

    public CloseAnimation(int width, int fromXType,
                          float fromXValue, int toXType, float toXValue, int fromYType,
                          float fromYValue, int toYType, float toYValue, RelativeLayout relLayout, LinearLayout linLayout) {

        super(fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue,
                toYType, toYValue);

        // Initialize
        RelLayout = relLayout;
        LinLayout = linLayout;
        panelWidth = width;
        setDuration(250);
        setFillAfter(false);
        setInterpolator(new AccelerateDecelerateInterpolator());
        setAnimationListener(this);

        if(RelLayout != null) {
            // Clear left and right margins
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) RelLayout.getLayoutParams();
            params.rightMargin = 0;
            params.leftMargin = 0;
            RelLayout.setLayoutParams(params);
            RelLayout.requestLayout();
            RelLayout.startAnimation(this);
        }else if(LinLayout != null){
            // Clear left and right margins
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) LinLayout.getLayoutParams();
            params.rightMargin = 0;
            params.leftMargin = 0;
            LinLayout.setLayoutParams(params);
            LinLayout.requestLayout();
            LinLayout.startAnimation(this);
        }

    }

    public void onAnimationEnd(Animation animation) {

    }

    public void onAnimationRepeat(Animation animation) {

    }

    public void onAnimationStart(Animation animation) {

    }

}