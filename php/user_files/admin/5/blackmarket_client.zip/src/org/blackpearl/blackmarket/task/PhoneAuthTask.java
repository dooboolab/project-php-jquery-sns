package org.blackpearl.blackmarket.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.blackpearl.blackmarket.network.Network;

import java.util.ArrayList;

/**
 * Created by hyochan on 2014. 8. 15..
 */
public class PhoneAuthTask extends AsyncTask<String, Integer, String>{

    private static final String TAG = "PhoneAuthTask";
    Context mContext;
    ReceivePhoneAuthResult receivePhoneAuthResult;

    ProgressDialog progressDialog;

    private int number;
    private String phone;
    ArrayList<BasicNameValuePair> nameValuePairs;

    public PhoneAuthTask(Context context, String phone, int number){
        mContext = context;
        this.phone = phone;
        this.number = number;
    }

    public void setOnResultListener(ReceivePhoneAuthResult getPhoneAuthResult){
        if(getPhoneAuthResult != null){
            this.receivePhoneAuthResult = getPhoneAuthResult;
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();



        // progress dialog
        progressDialog = new ProgressDialog(mContext);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("서버와 인증중입니다.");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(true);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                receivePhoneAuthResult.onResultFail(3, "사용자 취소");
                Log.i(TAG, "사용자 취소");
            }
        });

        progressDialog.show();

        Network network = new Network();
        if(network.isNetworkAvailable(mContext) == false) {
            receivePhoneAuthResult.onResultFail(1, "단말 오류");
            return;
        } else {
            // 서버에 전달할 파라메터 세팅
            nameValuePairs = new ArrayList<BasicNameValuePair>();
            // number is 0 if there is no data in db
            if(number == 0) {
                nameValuePairs.add(new BasicNameValuePair("phone", phone));
                Log.i(TAG, "send phone : " + phone);
            }
            else{
                nameValuePairs.add(new BasicNameValuePair("phone", phone));
                nameValuePairs.add(new BasicNameValuePair("number", Integer.toString(number)));
                Log.i(TAG, "send phone : " + phone + ", number : " + number);
            }
        }
    }

    @Override
    protected String doInBackground(String... url) {

        /* get 일단 막음
        try{
            URL mUrl = new URL(url[0]);
            HttpURLConnection urlConnection = (HttpURLConnection) mUrl.openConnection();
            urlConnection.connect();
        } catch (Exception e){
            Log.d("Exception while downloading url", e.toString());
        }
        */

        String result = "";
        try {
            HttpClient http = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url[0]);
            UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
            httpPost.setEntity(entityRequest);
            HttpResponse response = http.execute(httpPost);
            result = EntityUtils.toString(response.getEntity());
        }catch (HttpHostConnectException e){
            Log.i(TAG, "HttpHostConnectException");
            progressDialog.dismiss();
            receivePhoneAuthResult.onResultFail(0, "서버 오류");

        }catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    //get the returned text from the url
    @Override
    protected void onPostExecute(String result){
        progressDialog.dismiss();
        Log.i(TAG, "result : " + result);
        if(result.equals("") == false || result != null) {
            receivePhoneAuthResult.onResultSuccess(1, result);
        }else{
            receivePhoneAuthResult.onResultFail(2, result);
        }
    }

    public interface ReceivePhoneAuthResult {
        public abstract void onResultSuccess(final int resultCode, final String message);
        public abstract void onResultFail(final int resultCode, final String errorMessage);
    }


}
