package org.blackpearl.blackmarket.fragment;


import android.app.Fragment;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;

import org.blackpearl.blackmarket.MainActivity;
import org.blackpearl.blackmarket.R;
import org.blackpearl.blackmarket.adapter.HomeCategoryAdapter;
import org.blackpearl.blackmarket.animation.CloseAnimation;
import org.blackpearl.blackmarket.animation.OpenAnimation;
import org.blackpearl.blackmarket.data.MarketCategoryData;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 *
 */
public class HomeFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener{

    // layout
    // slide menu
    private DisplayMetrics metrics;
    private RelativeLayout mainLayout;
    private LinearLayout menuLayout;
    private ListView listView;
    private ImageView icon_edit;
    private ImageView icon_search;
    private FrameLayout.LayoutParams leftMenuLayoutPrams;
    private int leftMenuWidth;

    private static final int size_of_categories = 10;

    public HomeFragment() {
        // Required empty public constructor
    }


    public void menuLeftSlideAnimationToggle() {

        if (!MainActivity.isLeftExpanded) {
            MainActivity.isLeftExpanded = true;
            // Expand
            new OpenAnimation(leftMenuWidth,
                    Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, 0.45f, 0, 0.0f, 0, 0.0f, mainLayout, null);

            // enable all of menu view
            FrameLayout viewGroup = (FrameLayout) getView().findViewById(R.id.menuLayout)
                    .getParent();
            //enableDisableViewGroup(viewGroup, true);

            menuLayout.setVisibility(View.VISIBLE);
            new OpenAnimation(0,
                    Animation.RELATIVE_TO_SELF, -1.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f,
                    0, 0.0f, 0, 0.0f,
                    null, menuLayout);

        } else {
            MainActivity.isLeftExpanded = false;
            // Collapse
            new CloseAnimation(leftMenuWidth,
                    TranslateAnimation.RELATIVE_TO_SELF, 0.45f,
                    TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f, mainLayout, null);
            // enable all of menu view
            FrameLayout viewGroup = (FrameLayout) getView().findViewById(R.id.menuLayout)
                    .getParent();
            new CloseAnimation(0,
                    TranslateAnimation.RELATIVE_TO_SELF, 0.0f,
                    TranslateAnimation.RELATIVE_TO_SELF, -1.0f, 0, 0.0f, 0, 0.0f,
                    null, menuLayout);
            menuLayout.setVisibility(View.INVISIBLE);
            //enableDisableViewGroup(viewGroup, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //init ui
        icon_edit = (ImageView) view.findViewById(R.id.icon_edit);
        icon_search = (ImageView) view.findViewById(R.id.icon_search);
        listView = (ListView) view.findViewById(R.id.listView);
        listView.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);


        String[] categories_text = getResources().getStringArray(R.array.category);
        Integer[] categories_icon ={
                R.drawable.icon_all, R.drawable.icon_wear, R.drawable.icon_food,
                R.drawable.icon_hair, R.drawable.icon_hospital, R.drawable.icon_beauty,
                R.drawable.icon_sing, R.drawable.icon_pc, R.drawable.icon_coffee, R.drawable.icon_drink
        };

        ArrayList<MarketCategoryData> data =
                new ArrayList<MarketCategoryData>();
        for(int i=0; i<size_of_categories; i++){
            data.add(new MarketCategoryData
                    (categories_text[i], categories_icon[i]));
        }


        HomeCategoryAdapter adapter
                = new HomeCategoryAdapter(this.getActivity().getApplicationContext(),
                    R.layout.left_menu_list,
                    data);
        listView.setAdapter(adapter);
        listView.setOnItemSelectedListener(this);

        // init left menu width
        metrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);
        leftMenuWidth = (int) ((metrics.widthPixels) * 0.45);

        // init main view
        mainLayout = (RelativeLayout) view.findViewById(R.id.mainLayout);

        // init left menu
        menuLayout = (LinearLayout) view.findViewById(R.id.menuLayout);
        leftMenuLayoutPrams = (FrameLayout.LayoutParams) menuLayout
                .getLayoutParams();
        leftMenuLayoutPrams.width = leftMenuWidth;
        menuLayout.setLayoutParams(leftMenuLayoutPrams);
        menuLayout.setVisibility(View.INVISIBLE);

        icon_edit.setOnClickListener(this);

        return view;

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.icon_edit:
                menuLeftSlideAnimationToggle();
                break;
            default:
                break;
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
