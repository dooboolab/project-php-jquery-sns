package org.blackpearl.blackmarket.data;

import java.util.Date;

/**
 * Created by hyochan on 2014-09-10.
 */
public class ManagerMarketPreference {
    String name;
    String category;
    String phone;
    String address;
    String homepage;
    String main_product;
    int managers;
    int rating;
    String image;
    String movie;
    String time;

    public ManagerMarketPreference(String name, String category, String phone, String address, String homepage, String main_product, int managers, int rating, String image, String movie, String time) {
        this.name = name;
        this.category = category;
        this.phone = phone;
        this.address = address;
        this.homepage = homepage;
        this.main_product = main_product;
        this.managers = managers;
        this.rating = rating;
        this.image = image;
        this.movie = movie;
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getMain_product() {
        return main_product;
    }

    public void setMain_product(String main_product) {
        this.main_product = main_product;
    }

    public int getManagers() {
        return managers;
    }

    public void setManagers(int managers) {
        this.managers = managers;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
