package org.blackpearl.blackmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import org.blackpearl.blackmarket.data.AccessDB;
import org.blackpearl.blackmarket.network.NetworkPreference;
import org.blackpearl.blackmarket.task.PhoneAuthTask;
import org.json.JSONArray;
import org.json.JSONObject;

// 할일 : mainactivity 등록하기전에 registered 된 놈인지 한번 확인하고 시작 필요
// registered 된 놈이면 MainRegisteredActivty를 띄움.

public class LoadingActivity extends Activity {

    private static final String TAG = "LoadingActivity";
    PhoneAuthTask phoneAuthTask;
    String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        AccessDB.getInstance(LoadingActivity.this).insertSetting();
        /*
                시작 : 핸드폰 인증
        */
        TelephonyManager manager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        phone = manager.getLine1Number();

        Log.i(TAG, "phone number : " + phone);

        if (phone == "" ||phone == null){
            //다이얼로그 띄우기
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
            builder.setTitle("잘못된 접근입니다."); // 제목
            builder.setMessage("고객님의 휴대폰은 개통된 휴대폰이 아닙니다. 죄송합니다."); // 메시지
            builder.show();
            finish();
        }
        else{
            /// phone = phone.replace("+82", "0");
            phone = PhoneNumberUtils.formatNumber(phone.replace("+82", "0"));
        }

        // StrictMode.enableDefaults();
        /* start : unix.jang => the way of code to ignore the policy violoation */
        StrictMode.ThreadPolicy old = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(old)
                .permitDiskWrites()
                .build());
        // doCorrectStuffThatWritesToDisk();
        StrictMode.setThreadPolicy(old);
        /* end : unix.jang => ignoring policy violation */

        // 접속 URL
        String strUrl = NetworkPreference.getInstance(this).getServer_url() + "/phone";
        Log.i(TAG, "url : " + strUrl);

        phoneAuthTask = new PhoneAuthTask(LoadingActivity.this, phone, AccessDB.getInstance(LoadingActivity.this).selectManager(phone));
        phoneAuthTask.setOnResultListener(getPhoneAuthResult);
        phoneAuthTask.execute(strUrl);

        /*
            종료 : 휴대폰 인증
         */
    }

    PhoneAuthTask.ReceivePhoneAuthResult getPhoneAuthResult = new PhoneAuthTask.ReceivePhoneAuthResult() {
        @Override
        public void onResultSuccess(final int resultCode, final String message) {
            int server_number = 0;
            String server_phone = null;
            String server_id = null;

            Log.i(TAG, "onResultSuccess - code : " + resultCode + "\n" + message);

            try{
                JSONArray json = new JSONArray(message);
                JSONObject json_obj = json.getJSONObject(0);
                server_phone = json_obj.getString("phone");
                server_number = json_obj.getInt("number");
                server_id = json_obj.getString("id");
                Log.i(TAG, "phone : " + server_phone + ", number : " + server_number + ", id : " + server_id);
            }catch (Exception e){
                Log.i(TAG, "exception : " + e);
            }

            // Log.i(TAG, "Select Manager : " + AccessDB.getInstance(LoadingActivity.this).selectManager(server_phone));
            // Log.i(TAG, "server_number : " + server_number);

            // current user - successfully logged in
            if(server_phone.equals("") == false && server_number > 0){
                Log.i(TAG, "current user - successfully logged in");
                Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.putExtra("phone", server_phone);
                startActivity(intent);
                finish();
            }
            // new user - start SetNameActivity
            else if(server_phone.equals("") == false && server_number == 0){
                Log.i(TAG, "new user - start SetNameActivity");
                Intent intent = new Intent(LoadingActivity.this, SetNameActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("phone", server_phone);
                // requestCode 1 = SetNameActivity
                startActivityForResult(intent, 1);
            }
            // autentication error = start PasswordActivity
            else if(server_id.equals("") == false){
                Log.i(TAG, "autentication error = start PasswordActivity");
                Intent intent = new Intent(LoadingActivity.this, PasswordActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("id", server_id);
                // requestCode 2 = PasswordActivity
                startActivityForResult(intent, 2);
            }
        }

        @Override
        public void onResultFail(final int resultCode, final String errorMessage) {
            Log.i(TAG, "onResultFail - code : " + resultCode + "\n" + errorMessage);
            phoneAuthTask.cancel(true);
            // 네트워크 오류
            if(resultCode == 0) {
                if(LoadingActivity.this != null && !LoadingActivity.this.isFinishing()) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(LoadingActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("네트워크 오류"); // 제목
                            builder.setMessage("서버가 점검중입니다. 나중에 다시 이용해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    finish();
                                }
                            });
                            builder.show();
                        }
                    });
                }
            }
            // 단말 네트워크 오류
            else if(resultCode == 1) {
                if(LoadingActivity.this != null && !LoadingActivity.this.isFinishing()) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(LoadingActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("네트워크 오류"); // 제목
                            builder.setMessage("단말 인터넷이 비활성화 되었습니다. 활성화 후 다시 이용해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    finish();
                                }
                            });
                            builder.show();
                        }
                    });
                }
            }
            // 서버로부터 데이터를 받아오지 못함
            else if(resultCode == 2){
                if(LoadingActivity.this != null && !LoadingActivity.this.isFinishing()) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            //다이얼로그 띄우기
                            AlertDialog.Builder builder = new AlertDialog.Builder(LoadingActivity.this);
                            // AlertDialog.Builder 를 통해서 dialog 객체를 생성
                            builder.setTitle("서버 오류"); // 제목
                            builder.setMessage("서보로부터 데이터를 받아오지 못했습니다. 나중에 다시 이용해주세요."); // 메시지
                            builder.setCancelable(false);
                            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();     //닫기
                                    finish();
                                }
                            });
                            builder.show();
                        }
                    });
                }
            }
            // 사용자 취소
            else{
                finish();
            }
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.i(TAG, "requestCode : " + requestCode + ", resultCode : " + resultCode);

        // 1 == SetNameActivity
        if (requestCode == 1) {
            if(resultCode == RESULT_OK){

                // MainActivity로 접속
                Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            }
            if (resultCode == RESULT_CANCELED) {
                //Write your code if there's no result
                finish();
            }
        }
        // 2 == PasswordActivity
        else if (requestCode == 2) {
            int number = data.getIntExtra("number", 0);

            if(resultCode == RESULT_OK){
                if(number > 0) {
                    // MainActivity로 접속
                    Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    finish();
                } else{
                    // SetNameActivity로 접속
                    Intent intent = new Intent(LoadingActivity.this, SetNameActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.putExtra("phone", phone);
                    startActivityForResult(intent, 1);
                }
            }
            if (resultCode == RESULT_CANCELED) {
                //Write your code if there's no result
                //finish();
            }
        }
    }//onActivityResult

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.loading, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
