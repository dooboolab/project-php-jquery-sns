package org.blackpearl.blackmarket.network;

/**
 * Created by hyochan on 2014. 8. 16..
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import io.socket.SocketIO;

public class NetworkPreference {

    // commit test
    private static NetworkPreference mNetworkPreference;
    private SharedPreferences mPref;
    private Context mContext;
    private final String server_url = "http://blackpearl.webhop.org:52273";
    private SocketIO mSocket;

    private NetworkPreference(Context context){
        mPref = PreferenceManager.getDefaultSharedPreferences(context);
        mContext = context;
    }

    public static NetworkPreference getInstance(Context context){
        if(mNetworkPreference == null) mNetworkPreference = new NetworkPreference(context);
        return mNetworkPreference;

    }

    public String getServer_url() {
        return server_url;
    }

    public SocketIO getmSocket() {
        return mSocket;
    }

    public void setmSocket(SocketIO mSocket) {
        this.mSocket = mSocket;
    }
}
