package org.blackpearl.blackmarket.fragment;


import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import org.blackpearl.blackmarket.AddMarketActivity;
import org.blackpearl.blackmarket.R;
import org.blackpearl.blackmarket.adapter.ManagerMarketAdapter;
import org.blackpearl.blackmarket.data.ManagerMarketPreference;
import org.blackpearl.blackmarket.data.ManagerPreference;
import org.blackpearl.blackmarket.network.NetworkPreference;
import org.blackpearl.blackmarket.task.GetManagerMarketTask;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class ManagerFragment extends Fragment implements View.OnClickListener{

    private final String TAG = "ManagerFragment";

    Context mContext;
    TextView text_username;
    TextView text_phone;
    TextView text_userId;
    ListView marketLists;

    ImageButton icon_plus;

    ArrayList<ManagerMarketPreference> arrayListManagerMarket;
    ManagerMarketAdapter managerMarketAdapter;

    public ManagerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mContext = getActivity().getApplicationContext();

        arrayListManagerMarket = new ArrayList<ManagerMarketPreference>();

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manager, container, false);

        text_username = (TextView) view.findViewById(R.id.text_username);
        text_phone = (TextView) view.findViewById(R.id.text_phone);
        text_userId = (TextView) view.findViewById(R.id.text_userId);
        marketLists = (ListView) view.findViewById(R.id.markets_list);

        text_username.setText(ManagerPreference.getInstance(mContext).getName());
        text_phone.setText(ManagerPreference.getInstance(mContext).getPhone());

        icon_plus = (ImageButton) view.findViewById(R.id.icon_plus);
        icon_plus.setOnClickListener(this);

        return view;

    }

    @Override
    public void onResume() {
        super.onResume();
        icon_plus.setSelected(false);

        String id = ManagerPreference.getInstance(mContext).getId();
        Log.i(TAG, "getID : " + id);

        if(id.compareTo("") != 4){
            Log.i(TAG, "id not null : " + id.compareTo(""));
            text_userId.setText(id);
            text_userId.setTextColor(Color.parseColor("#000000"));
            // get manager's markets from server
            String strUrl = NetworkPreference.getInstance(mContext).getServer_url() + "/manager_market";
            Log.i(TAG, "url : " + strUrl);
            GetManagerMarketTask getManagerMarketTask = new GetManagerMarketTask(mContext, id);
            getManagerMarketTask.setOnResultListener(getManagerMarketResult);
            getManagerMarketTask.execute(strUrl);
        }
    }

    GetManagerMarketTask.GetManagerMarketResult getManagerMarketResult = new GetManagerMarketTask.GetManagerMarketResult() {
        @Override
        public void onResultSuccess(int resultCode, String message) {
            Log.i(TAG, "getManagerMarketResult success : " + message);
            arrayListManagerMarket.clear();
            try {
                JSONArray json = new JSONArray(message);
                for(int i =0; i<json.length(); i++) {
                    JSONObject json_obj = json.getJSONObject(i);
                    ManagerMarketPreference managerMarketPreference = new ManagerMarketPreference(
                            json_obj.getString("name"),
                            json_obj.getString("category"),
                            json_obj.getString("phone"),
                            json_obj.getString("address"),
                            json_obj.getString("homepage"),
                            json_obj.getString("main_product"),
                            json_obj.getInt("managers"),
                            json_obj.getInt("rating"),
                            json_obj.getString("image"),
                            json_obj.getString("movie"),
                            json_obj.getString("time")
                    );
                    // set arrayListManagerMarket array for listview adapter
                    arrayListManagerMarket.add(managerMarketPreference);

                    managerMarketAdapter = new ManagerMarketAdapter(mContext,
                            R.layout.manager_market_list, R.id.market_name, arrayListManagerMarket);
                    marketLists.setAdapter(managerMarketAdapter);
                }
            }catch (Exception e){
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            }
        }

        @Override
        public void onResultFail(int resultCode, String errorMessage) {
            Log.i(TAG, "getManagerMargetResult failed");
        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.icon_plus:
                icon_plus.setSelected(true);
                startActivity(new Intent(mContext, AddMarketActivity.class));
                break;
        }
    }
}
