package org.blackpearl.blackmarket.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by hyochan on 2014. 8. 16..
 */
public class ManagerPreference {
    int number = 0;
    String name;
    String phone;
    int markets;
    String image;
    String email;
    String id;
    String password;

    Context mContext;
    SharedPreferences mPref;
    private static ManagerPreference mInstance;

    private ManagerPreference(Context context){
        mPref = PreferenceManager.getDefaultSharedPreferences(context);
        mContext = context;
    }

    public static ManagerPreference getInstance(Context context){
        if(mInstance == null) mInstance = new ManagerPreference(context);
        return mInstance;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getMarkets() {
        return markets;
    }

    public void setMarkets(int markets) {
        this.markets = markets;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
