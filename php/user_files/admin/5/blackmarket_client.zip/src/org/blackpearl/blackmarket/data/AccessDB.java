package org.blackpearl.blackmarket.data;

/**
 * Created by hyochan on 2014. 8. 15..
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.util.Log;

public class AccessDB {

    private static final String TAG = "AccessDB";
    private int dbVersion = 1;
    private String db_manager = "manager.db";
    private String db_market = "market.db";
    private String db_owns = "owns.db";
    private static AccessDB mInstance;
    private SharedPreferences mPref;
    private DBHelper mDBHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private Context mContext;


    private AccessDB(Context context){
        mPref = PreferenceManager.getDefaultSharedPreferences(context);
        mContext = context;
    }

    public static AccessDB getInstance(Context context){
        if(mInstance == null) mInstance = new AccessDB(context);
        return mInstance;
    }

    public void insertSetting(){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        cursor = db.rawQuery("SELECT * FROM setting", null);
        if(cursor.getCount() == 0) {
            String sql = "INSERT INTO setting VALUES(null, 0,0)";
            db.execSQL(sql);
        }
        mDBHelper.close();
    }

    // registered 변수는 마켓 소유자가 아니냐를 나중에 판별하기 위함.
    // 만약 사용자가 id를 만들고 마켓을 등록하면 register변수는 1로 되고 fragment 버튼은 4개로 늘어날 예정
    // 새로운 1개 fragment는 본인의 마켓에 들어오는 메시지를 관리하는 창
    public void updateSettingRegistered(Integer registered){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String sql = "UPDATE setting SET registered = " + registered;
        db.execSQL(sql);
        mDBHelper.close();
    }

    public int getSettingRegistered(){
        int result;
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        cursor = db.rawQuery(
                "SELECT registered FROM setting", null);
        if(cursor.getCount() ==0){
            return 0;
        }
        cursor.moveToFirst();
        result = cursor.getInt(0);
        mDBHelper.close();
        return result;
    }

    public void updateSettingFragment(Integer fragment){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String sql = "UPDATE setting SET fragment = " + fragment;
        db.execSQL(sql);
        mDBHelper.close();
    }

    public int getSettingFragment(){
        int result;
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        cursor = db.rawQuery(
                "SELECT fragment FROM setting", null);
        if(cursor.getCount() == 0){
            result = 0;
            mDBHelper.close();
        }
        else{
            cursor.moveToFirst();
            result = cursor.getInt(0);
            mDBHelper.close();
        }

        return result;
    }

    public int selectManager(String phone){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String[] args = {phone};
        int number = 0;
        Log.i(TAG, "phone : " + phone);
        cursor = db.rawQuery(
                "SELECT * FROM manager WHERE phone = ?", args);
        if(cursor.getCount() != 0) {
            cursor.moveToFirst();
            ManagerPreference.getInstance(mContext).setNumber(cursor.getInt(0));
            ManagerPreference.getInstance(mContext).setName(cursor.getString(1));
            ManagerPreference.getInstance(mContext).setPhone(cursor.getString(2));
            ManagerPreference.getInstance(mContext).setMarkets(cursor.getInt(3));
            ManagerPreference.getInstance(mContext).setImage(cursor.getString(4));
            ManagerPreference.getInstance(mContext).setEmail(cursor.getString(5));
            ManagerPreference.getInstance(mContext).setId(cursor.getString(6));
            ManagerPreference.getInstance(mContext).setPassword(cursor.getString(7));

            Log.i(TAG, "Manager Preference - \n" +
                "number : " + ManagerPreference.getInstance(mContext).getNumber() + ", \n" +
                "name : " + ManagerPreference.getInstance(mContext).getName() + ", \n" +
                "phone : " + ManagerPreference.getInstance(mContext).getPhone() + ", \n" +
                "markets : " + ManagerPreference.getInstance(mContext).getMarkets() + ", \n" +
                "image : " + ManagerPreference.getInstance(mContext).getImage() + ", \n" +
                "email : " + ManagerPreference.getInstance(mContext).getEmail() + ", \n" +
                "id : " + ManagerPreference.getInstance(mContext).getId() + ", \n" +
                "password : " + ManagerPreference.getInstance(mContext).getPassword() + ", \n"
            );


        }
        mDBHelper.close();
        return ManagerPreference.getInstance(mContext).getNumber();
    }

    public void insertManager(Integer number, String name,
                              String phone, Integer markets,
                              String Image, String email,
                              String id, String password){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String sql = "INSERT INTO manager VALUES( " +
                number + ", " +
                "'" + name + "', " +
                "'" + phone + "'," +
                markets + ", " +
                "'" + Image + "', " +
                "'" + email + "', " +
                "'" + id + "', " +
                "'" + password + "' " +
                ")";
        db.execSQL(sql);

        mDBHelper.close();
        selectManager(phone);
    }

    public void updateManager(Integer number, String name, String phone, Integer markets, Integer Image){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String sql = "UPDATE manager SET name='"
                + name + "' WHERE number = " + number;
        db.execSQL(sql);
        mDBHelper.close();
    }

    public void deleteManager(String today){
        mDBHelper = new DBHelper(mContext, db_manager, null, dbVersion);
        db = mDBHelper.getWritableDatabase();
        String sql = "DELETE FROM today WHERE date = '" + today + "'";
        db.execSQL(sql);
        mDBHelper.close();
    }

}
