package ch11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBChangeTable {
	protected Connection conn = null;
	protected String Driver = "jdbc:mysql://localhost:3306/mydb?useUnicode=true&characterEncoding=utf8";
	protected String User = "root";
	protected String Pass = "wlvlwlrl87!";
	protected ResultSet rs;
	protected int row;
	
	public static void main(String arg[]){
		DBChangeTable table = new DBChangeTable();
		/*
		String query1 = "CREATE TABLE `tblMember` "
				+ "(`id` char(20) NOT NULL, "
				+ "`pass` char(20) NOT NULL, "
				+ "`name` char(20) NOT NULL, "
				+ "`sex` char(1) NOT NULL, "
				+ "`birthday` char(6) NOT NULL, "
				+ "`email` char(30) NOT NULL, "
				+ "`zipcode` char(7) NOT NULL, "
				+ "`address` char(50) NOT NULL, "
				+ "`hobby` char(5) NOT NULL, "
				+ "`job` char(20) NOT NULL, PRIMARY KEY (`id`));";
		
		String query2 = "CREATE TABLE `tblZipcode` "
				+ "(`zipcode` char(7) NOT NULL, "
				+ "`area1` char(10) DEFAULT NULL, "
				+ "`area2` char(20) DEFAULT NULL, "
				+ "`area3` char(40) DEFAULT NULL, "
				+ "`area4` char(20) DEFAULT NULL)";
		
		DBChangeTable table = new DBChangeTable();
		table.change_table(query1);
		table.change_table(query2);
		
		String query3 = "insert into tblMember"
				+ "(ID, PASS, NAME, SEX, BIRTHDAY, EMAIL, ZIPCODE, ADDRESS,HOBBY, JOB)"
				+ "VALUES('mistary', 'pass', '김준형', '남', '1987', 'vbass@naver.com', "
				+ "'6221', '서울시 송파구 잠실동', '컴퓨터', '프로그래머');";

		table.change_table(query3);
		*/

	}
	
	public void change_table(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다.!\n");
			
			PreparedStatement sql = conn.prepareStatement(query);
			row = sql.executeUpdate();
			
			System.out.println(row + "테이블이 생성되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("MYSQL 예외발생 : " + e);
				}
			}
		}
	}
}