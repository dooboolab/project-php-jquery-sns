package bean;

import java.sql.*;

public class DriverTest{
	public static void main(String args[]){
		try{
			Class.forName("org.gjt.mm.mysql.Driver").newInstance();
			DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "wlvlwlrl87!");
			System.out.println("Success");
		}
		catch(SQLException ex){ System.out.println("SQLException" + ex);}
		catch(Exception ex){ System.out.println("Exception:" + ex);}
	}
}