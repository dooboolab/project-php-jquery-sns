package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateTable {
	protected Connection conn = null;
	protected String Driver = "jdbc:mysql://localhost:3306/mydb?useUnicode=true&characterEncoding=utf8";
	protected String User = "root";
	protected String Pass = "wlvlwlrl87!";
	protected ResultSet rs;
	protected int row;
	
	public static void main(String arg[]){
		/*
		String query1 = "Create Table tblRegister(id VARCHAR(20) NOT NULL,"
				+ "passwd VARCHAR(20) NOT NULL,"
				+ "name CHAR(6) NOT NULL,"
				+ "num1 CHAR(7) NULL,"
				+ "num2 CHAR(7) NULL,"
				+ "email VARCHAR(30) NULL,"
				+ "phone VARCHAR(30) NULL,"
				+ "zipcode CHAR(7) NULL,"
				+ "address VARCHAR(60) NULL,"
				+ "job VARCHAR(30) NULL)";
		
		String query2 = "insert into tblRegister"
				+ "(ID, PASSWD, NAME, NUM1, NUM2, EMAIL, PHONE, ZIPCODE, ADDRESS, JOB)"
				+ "VALUES('vbass', '11111111', '김준형', '1234567', '1234567', 'vbass@naver.com', "
				+ "'011-111-1111', '111-111', '하와이', '프로그래머');";
		
		CreateTable table = new CreateTable();
		table.change_table(query1);
		table.change_table(query2);
		*/
	}
	
	public void change_table(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다.!\n");
			
			PreparedStatement sql = conn.prepareStatement(query);
			row = sql.executeUpdate();
			
			System.out.println("테이블이 생성되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("MYSQL 예외발생 : " + e);
				}
			}
		}
	}
}
