package database;

public class test {
	
	public static void main(String args[]){
		MyPropertie A = new MyPropertie();
		String str = "안녕하세요";
		A.setA(str);
		System.out.println(A.getA());
	}
}
