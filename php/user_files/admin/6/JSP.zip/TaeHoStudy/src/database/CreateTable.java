package database;
import model.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CreateTable {
	
	private static String query;
	protected static Connection conn = null;
	protected static String Driver = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=UTF-8";
	protected static String User = "root";
	protected static String Pass = "wlvlwlrl87!";
	//rs는 쿼리 결과값을 받아오는 변수
	protected ResultSet rs;
	//sql은 sql문
	protected PreparedStatement sql;
	//select 시 결과값을 받아오는 ArrayList
	private ArrayList<board>  mBoard = new ArrayList<board>();
	
	public static void connect(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다!\n");
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		}
	}
	
	//메인함수를 이용해서 데이터데이스 테이블을 만든다.
	public static void main(String arg[]){
		CreateTable table = new CreateTable();
		query = "CREATE TABLE board ("
				+ "name varchar(16), "
				+ "age integer, "
				+ "content text, "
				+ "PRIMARY KEY (`name`))";
		table.update_table(query);
	}

	public void update_table(String query){
		try {		
			connect();
			sql = conn.prepareStatement(query);
			sql.executeUpdate();
			
			System.out.println("테이블이 변경되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("MYSQL 예외발생 : " + e);
				}
			}
		}
	}
	public ArrayList<board> execute_table(String query){
		try {
			connect();
			
			sql = conn.prepareStatement(query);
			rs = sql.executeQuery();

			while(rs.next()){
				board mData = new board();
				mData.setName(rs.getString(1));
				mData.setAge(rs.getInt(2));
				mData.setText(rs.getString(3));
				
				mBoard.add(mData);
			}
			System.out.println("제대로 select 되었음");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("MSQL 예외발생 : " + e);
				}
			}
		}
		return mBoard;
	}

}