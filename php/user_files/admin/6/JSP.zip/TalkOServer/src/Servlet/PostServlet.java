package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PostServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,
						HttpServletResponse response)
						throws IOException, ServletException{
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("NAME");
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>게시판 글쓰기</title></head>");
		out.println("</html>");
		
		// 같은 서버의 자원을 리다이렉트
		response.sendRedirect("index.jsp");
		// 다른 서버의 자원을 리다이렉트
		// response.sendRedirect("http://www.naver.com");

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}
	
}
