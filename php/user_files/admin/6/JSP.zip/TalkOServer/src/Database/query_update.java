package Database;

import java.sql.*;

public class query_update extends query{	
	private int row;
	
	//public static void main(String[] args) {}
	
	public void create_table(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다.!\n");
			
			PreparedStatement sql = conn.prepareStatement(query);
			row = sql.executeUpdate();
			
			System.out.println(row + "테이블이 생성되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("MYSQL 예외발생 : " + e);
				}
			}
		}
	}
	
	public void insert_table(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다!\n");
			
			PreparedStatement sql = conn.prepareStatement(query);
			row = sql.executeUpdate();
			
			System.out.println(row + "가 성공적으로 입력되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("SQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("SQL 예외발생 : " + e);
				}
			}
		}
	}
	
	public void delete_table(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(Driver, User, Pass);
			System.out.print("MySQL 데이터베이스에 접속했습니다!\n");
			
			PreparedStatement sql = conn.prepareStatement(query);
			row = sql.executeUpdate();
			System.out.println(row + "명령이 실행되었습니다.");
			
		} catch (SQLException e) {
			System.out.println("MYSQL 예외발생 : " + e);
		} catch (Exception ex) {
			System.out.println("예외발생 : " + ex);
		} finally {
			if (conn != null) {
				try{
					conn.close();
					System.out.println("MySQL 연결종료");
				} catch (SQLException e) {
					System.out.println("SQL 예외발생 : " + e);
				}
			}
		}
	}
}
