package com.kt.ollehcontact_v1.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.kt.ollehcontact_v1.R;
import com.kt.ollehcontact_v1.animation.SetVisibleAnimation;

/**
 * Created by hyochan on 14. 10. 21..
 */
public class MainFragment extends Fragment implements View.OnClickListener{

    private static final String TAG = "MainFragment";
    Context context;
    SlidingDrawer slidingDrawer;
    FrameLayout mainLayout;
    LinearLayout menuLayout;
    LinearLayout layoutTopButtons;
    LinearLayout layoutBody;
    LinearLayout layoutButtomButtons;

    private boolean isMenuExpanded;

    // left menu element
    Button btnRecent;
    Button btnAll;
    Button btnFavorite;
    Button btnProfile;

    // main layout element
    ImageView iconHamburger;
    ImageView iconEdit;

    public  MainFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        context = getActivity().getApplicationContext();

        mainLayout = (FrameLayout) view.findViewById(R.id.main_frame);
        menuLayout = (LinearLayout) view.findViewById(R.id.menuLayout);
        slidingDrawer = (SlidingDrawer) view.findViewById(R.id.slidingDrawer);

        // init left menu
        menuLayout.setVisibility(View.INVISIBLE);

        // init leftmenu elements
        btnRecent = (Button) view.findViewById(R.id.btn_recent);
        btnAll = (Button) view.findViewById(R.id.btn_all);
        btnFavorite = (Button) view.findViewById(R.id.btn_favorite);
        btnProfile = (Button) view.findViewById(R.id.btn_profile);

        // init main layout elements

        iconHamburger = (ImageView) view.findViewById(R.id.icon_hamburger);
        iconEdit = (ImageView) view.findViewById(R.id.icon_edit);
        layoutTopButtons = (LinearLayout) view.findViewById(R.id.layout_top_buttons);
        layoutBody = (LinearLayout) view.findViewById(R.id.layout_body);
        layoutButtomButtons = (LinearLayout) view.findViewById(R.id.layout_bottom_buttons);

        iconHamburger.setOnClickListener(this);

        slidingDrawer.setOnDrawerScrollListener(new SlidingDrawer.OnDrawerScrollListener() {
            @Override
            public void onScrollStarted() {

                // close menuLayout if Expanded
                if(isMenuExpanded){
                    SetVisibleAnimation setVisibleAnimation = new SetVisibleAnimation();
                    setVisibleAnimation.slideGoneLeft(menuLayout);
                    setVisibleAnimation.slideLeft(layoutTopButtons, menuLayout.getWidth());
                    setVisibleAnimation.slideLeft(layoutBody, menuLayout.getWidth());
                    setVisibleAnimation.slideLeft(layoutButtomButtons, menuLayout.getWidth());
                    isMenuExpanded = false;
                }
            }

            @Override
            public void onScrollEnded() {

            }
        });

        return view;
    }

    @Override
    public void onClick(View v) {
        int number = v.getId();
        switch (number){
            case R.id.icon_hamburger:
                Log.i(TAG, "icon_hamburger clicked");
                SetVisibleAnimation setVisibleAnimation = new SetVisibleAnimation();
                if(isMenuExpanded == false){
                    setVisibleAnimation.slideVisibleRight(menuLayout);
                    setVisibleAnimation.slideRight(layoutTopButtons, menuLayout.getWidth());
                    setVisibleAnimation.slideRight(layoutBody, menuLayout.getWidth());
                    setVisibleAnimation.slideRight(layoutButtomButtons, menuLayout.getWidth());
                    isMenuExpanded = true;
                }else{
                    setVisibleAnimation.slideGoneLeft(menuLayout);
                    setVisibleAnimation.slideLeft(layoutTopButtons, menuLayout.getWidth());
                    setVisibleAnimation.slideLeft(layoutBody, menuLayout.getWidth());
                    setVisibleAnimation.slideLeft(layoutButtomButtons, menuLayout.getWidth());
                    isMenuExpanded = false;
                }
                break;
        }
    }
}