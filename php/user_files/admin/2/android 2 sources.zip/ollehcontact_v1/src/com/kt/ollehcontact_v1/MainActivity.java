package com.kt.ollehcontact_v1;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import com.kt.ollehcontact_v1.adapter.ViewPagerAdapter;

public class MainActivity extends FragmentActivity {
    /**
     * Called when the activity is first created.
     */

    ViewPager pager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewPagerAdapter pageAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        pager = (ViewPager)findViewById(R.id.myViewPager);
        pager.setAdapter(pageAdapter);
    }
}
