package com.kt.ollehcontact_v1.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.kt.ollehcontact_v1.fragment.MainFragment;
import com.kt.ollehcontact_v1.fragment.SecondFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hyochan on 14. 10. 21..
 */
public class ViewPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> fragments;

    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
        this.fragments = new ArrayList<Fragment>();
        fragments.add(new MainFragment());
        fragments.add(new SecondFragment());
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}

