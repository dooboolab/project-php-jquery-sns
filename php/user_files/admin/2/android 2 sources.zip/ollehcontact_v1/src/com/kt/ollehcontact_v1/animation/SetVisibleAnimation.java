package com.kt.ollehcontact_v1.animation;

import android.view.View;
import android.view.animation.TranslateAnimation;

/**
 * Created by hyochan on 14. 10. 27..
 */
public class SetVisibleAnimation {
    // To animate view slide out from left to right

    private static final int duration = 100;

    public void slideVisibleRight(View view){
        TranslateAnimation animate = new TranslateAnimation(-view.getWidth(),0,0,0);
        animate.setDuration(duration);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.VISIBLE);
    }
    public void slideGoneLeft(View view){
        TranslateAnimation animate = new TranslateAnimation(0,-view.getWidth(),0,0);
        animate.setDuration(duration);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }
    public void slideRight(View view, int width){
        TranslateAnimation animate = new TranslateAnimation(0,width,0,0);
        animate.setDuration(duration);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }
    public void slideLeft(View view, int width){
        TranslateAnimation animate = new TranslateAnimation(width,0,0,0);
        animate.setDuration(duration);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }

}
